# Nuxt.js Architecture - Kiến Trúc Chi Tiết

## Mục lục
1. [Tổng quan Kiến trúc](#1-tổng-quan-kiến-trúc)
2. [Directory Structure](#2-directory-structure)
3. [Rendering Modes](#3-rendering-modes)
4. [Data Flow](#4-data-flow)
5. [Server Engine](#5-server-engine)
6. [State Management](#6-state-management)
7. [Module System](#7-module-system)

---

## 1. Tổng quan Kiến trúc

### 1.1 Nuxt Overview

Nuxt là full-stack framework được xây dựng trên Vue.js, cung cấp server-side rendering, static site generation, và các tính năng enterprise-ready. Nuxt 3 sử dụng Nitro server engine và Vite bundler.

Core features của Nuxt:
- **Universal Rendering**: SSR, SSG, ISR, CSR modes
- **Auto-imports**: Tự động import components, composables, utilities
- **File-based Routing**: Pages tự động tạo routes
- **Server Routes**: API endpoints trong server/api/
- **Module System**: Mở rộng functionality

### 1.2 Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                         NUXT APPLICATION                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                      PAGES LAYER                              │   │
│  │  ├── pages/index.vue                                          │   │
│  │  ├── pages/about.vue                                          │   │
│  │  ├── pages/products/[id].vue                                  │   │
│  │  └── pages/[...slug].vue                                      │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    COMPONENTS LAYER                          │   │
│  │  ├── components/ (auto-imported)                             │   │
│  │  ├── layouts/                                               │   │
│  │  └── pages/                                                 │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    COMPOSABLES LAYER                          │   │
│  │  ├── composables/ (auto-imported)                           │   │
│  │  ├── utils/ (auto-imported)                                 │   │
│  │  └── plugins/                                               │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│          ┌───────────────────┼───────────────────┐                │
│          │                   │                   │                  │
│          ▼                   ▼                   ▼                   │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐          │
│  │   Vue Layer  │  │   State      │  │   Server     │          │
│  │               │  │   Layer      │  │   Layer      │          │
│  │  - ref()      │  │  - useState │  │              │          │
│  │  - computed() │  │  - Pinia    │  │  - API       │          │
│  │  - watch()    │  │  - Cookie   │  │  - Database  │          │
│  └───────────────┘  └───────────────┘  └───────────────┘          │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 2. Directory Structure

### 2.1 Standard Nuxt 3 Structure

```
project/
├── .output/                    # Build output
├── .nuxt/                      # Nuxt build files (generated)
├── .output/                    # Production build
│
├── app.vue                     # Root app component
├── nuxt.config.ts              # Nuxt configuration
├── package.json
├── tsconfig.json
│
├── assets/                     # Uncompiled assets
│   ├── css/
│   │   └── main.css
│   └── images/
│
├── components/                 # Vue components (auto-imported)
│   ├── global/                # Global components
│   │   └── AppHeader.vue
│   ├── icons/                 # Icon components
│   │   └── IconSearch.vue
│   └── Ui/                    # UI component library
│       ├── Button.vue
│       ├── Card.vue
│       └── Modal.vue
│
├── composables/                # Reusable composition functions (auto-imported)
│   ├── useAuth.ts
│   ├── useFetchUser.ts
│   ├── useCounter.ts
│   └── useLocalStorage.ts
│
├── content/                    # Nuxt Content module
│   ├── getting-started.md
│   └── guides/
│       └── installation.md
│
├── layouts/                   # Page layouts
│   ├── default.vue
│   ├── auth.vue
│   └── admin.vue
│
├── middleware/                # Route middleware
│   ├── auth.ts               # Authentication middleware
│   ├── analytics.ts          # Analytics tracking
│   └── locale.global.ts      # Global middleware
│
├── pages/                      # File-based routing
│   ├── index.vue              # /
│   ├── about.vue              # /about
│   ├── contact.vue            # /contact
│   │
│   ├── products/
│   │   ├── index.vue         # /products
│   │   ├── [id].vue          # /products/:id
│   │   └── [category]/
│   │       ├── index.vue     # /products/:category
│   │       └── [product].vue # /products/:category/:product
│   │
│   ├── blog/
│   │   ├── index.vue         # /blog
│   │   ├── [slug].vue        # /blog/:slug
│   │   └── [year]/
│   │       └── [month].vue   # /blog/:year/:month
│   │
│   └── [...slug].vue          # Catch-all route
│
├── plugins/                    # Vue plugins (run on app start)
│   ├── api.ts                # API client plugin
│   ├── auth.ts               # Auth plugin
│   └── toast.client.ts        # Client-only plugin
│
├── public/                     # Static files (served as-is)
│   ├── favicon.ico
│   ├── robots.txt
│   └── og-image.png
│
├── server/                     # Nitro server
│   ├── api/                  # API routes
│   │   ├── hello.get.ts      # GET /api/hello
│   │   ├── users/
│   │   │   ├── index.get.ts  # GET /api/users
│   │   │   ├── index.post.ts # POST /api/users
│   │   │   └── [id].get.ts   # GET /api/users/:id
│   │   └── products/
│   │       ├── [id].get.ts
│   │       └── [id].put.ts
│   │
│   ├── middleware/            # Server middleware
│   │   └── cors.ts
│   │
│   ├── plugins/              # Server plugins
│   │   └── database.ts
│   │
│   ├── utils/                # Server utilities
│   │   ├── db.ts
│   │   └── auth.ts
│   │
│   └── routes/               # Server routes (non-API)
│       └── health.get.ts     # GET /health
│
├── utils/                     # Utility functions (auto-imported)
│   ├── formatters.ts
│   ├── validators.ts
│   └── constants.ts
│
└── types/                     # TypeScript type definitions
    ├── index.ts
    └── api.d.ts
```

### 2.2 Feature-Based Structure (Alternative)

```
project/
├── app/
│   ├── pages/
│   ├── layouts/
│   └── App.vue
│
├── features/
│   ├── auth/
│   │   ├── components/
│   │   │   ├── LoginForm.vue
│   │   │   └── RegisterForm.vue
│   │   ├── composables/
│   │   │   └── useAuth.ts
│   │   ├── pages/
│   │   │   ├── login.vue
│   │   │   └── register.vue
│   │   ├── server/
│   │   │   └── api/
│   │   │       └── auth.post.ts
│   │   └── middleware/
│   │       └── auth.ts
│   │
│   ├── products/
│   │   ├── components/
│   │   ├── pages/
│   │   └── server/
│   │
│   └── cart/
│       └── ...
│
├── shared/
│   ├── components/
│   ├── composables/
│   └── utils/
│
├── nuxt.config.ts
└── package.json
```

---

## 3. Rendering Modes

### 3.1 Rendering Modes Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                      RENDERING MODES                                  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                         SSR (Server-Side Rendering)          │   │
│  │                                                              │   │
│  │   Request ──► Server ──► Render ──► HTML ──► Client          │   │
│  │                    │          │           │                  │   │
│  │                    │          │           ▼                  │   │
│  │                    │          │      Hydration               │   │
│  │                    │          │                             │   │
│  │   Use Case: User-specific content, SEO-critical pages         │   │
│  │   Config: routeRules: { '/profile': { ssr: true } }        │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                       SSG (Static Site Generation)          │   │
│  │                                                              │   │
│  │   Build ──► Generate HTML ──► Deploy ──► CDN               │   │
│  │                         │                                   │   │
│  │   Use Case: Blogs, docs, marketing sites                    │   │
│  │   Config: routeRules: { '/': { prerender: true } }         │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    SPA (Single Page Application)             │   │
│  │                                                              │   │
│  │   Initial ──► HTML ──► JS Bundle ──► Hydration ──► Router  │   │
│  │                         │                                   │   │
│  │   Use Case: Dashboards, authenticated areas                 │   │
│  │   Config: routeRules: { '/dashboard/**': { ssr: false } }  │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │               ISR (Incremental Static Regeneration)          │   │
│  │                                                              │   │
│  │   Build ──► Generate ──► Cache ──► Revalidate ──► Update  │   │
│  │                                   │                         │   │
│  │   Use Case: E-commerce, frequently updated content          │   │
│  │   Config: routeRules: { '/blog/**': { swr: 3600 } }        │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 3.2 Route Rules Configuration

```typescript
// nuxt.config.ts
export default defineNuxtConfig({
  routeRules: {
    // Static generation at build time
    '/': { prerender: true },
    
    // ISR with 1 hour cache
    '/blog/**': { swr: 3600 },
    
    // SSR for dynamic content
    '/profile/**': { ssr: true },
    
    // SPA mode (client-side rendering)
    '/dashboard/**': { ssr: false },
    
    // Redirects
    '/old-page': { redirect: '/new-page' },
    
    // Headers
    '/api/**': { 
      cors: true,
      headers: { 'Cache-Control': 'no-cache' },
    },
  },
});
```

---

## 4. Data Flow

### 4.1 Server-Side Data Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                    SERVER-SIDE DATA FLOW                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  Browser Request                                                    │
│       │                                                             │
│       ▼                                                             │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                      NUXT SERVER                             │   │
│  │                                                               │   │
│  │  ┌──────────────────────────────────────────────────────┐   │   │
│  │  │                    Middleware                         │   │   │
│  │  │  ┌─────────┐  ┌─────────┐  ┌─────────┐              │   │   │
│  │  │  │   CORS  │  │  Auth   │  │  Rate   │              │   │   │
│  │  │  │         │  │         │  │  Limit  │              │   │   │
│  │  │  └─────────┘  └─────────┘  └─────────┘              │   │   │
│  │  └──────────────────────────────────────────────────────┘   │   │
│  │                            │                                 │   │
│  │                            ▼                                 │   │
│  │  ┌──────────────────────────────────────────────────────┐   │   │
│  │  │                    Route Handler                      │   │   │
│  │  │  ┌─────────────────────────────────────────────┐    │   │   │
│  │  │  │           useAsyncData / useFetch           │    │   │   │
│  │  │  │                                             │    │   │   │
│  │  │  │  ┌─────────┐  ┌─────────┐  ┌─────────┐    │    │   │   │
│  │  │  │  │ Server  │  │   DB    │  │   API   │    │    │   │   │
│  │  │  │  │  Route  │──│ Query   │──│  Call   │    │    │   │   │
│  │  │  │  └─────────┘  └─────────┘  └─────────┘    │    │   │   │
│  │  │  └─────────────────────────────────────────────┘    │   │   │
│  │  └──────────────────────────────────────────────────────┘   │   │
│  │                            │                                 │   │
│  │                            ▼                                 │   │
│  │  ┌──────────────────────────────────────────────────────┐   │   │
│  │  │                   Render Page                          │   │   │
│  │  │  ┌─────────────────────────────────────────────────┐ │   │   │
│  │  │  │  ┌─────────┐  ┌─────────┐  ┌─────────┐        │ │   │   │
│  │  │  │  │ Layout  │  │  Page   │  │Components│        │ │   │   │
│  │  │  │  └─────────┘  └─────────┘  └─────────┘        │ │   │   │
│  │  │  └─────────────────────────────────────────────────┘ │   │   │
│  │  └──────────────────────────────────────────────────────┘   │   │
│  │                            │                                 │   │
│  └────────────────────────────┼─────────────────────────────────┘   │
│                               │                                       │
│                               ▼                                       │
│                        HTML + JSON Payload                          │
│                               │                                       │
│                               ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                        CLIENT                                │   │
│  │  ┌─────────────────────────────────────────────────────┐   │   │
│  │  │                   Hydration                            │   │   │
│  │  │  - Vue takes over                                    │   │   │
│  │  │  - Event handlers attached                           │   │   │
│  │  │  - Interactive components ready                       │   │   │
│  │  └─────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 4.2 useFetch vs useAsyncData

```
┌─────────────────────────────────────────────────────────────────────┐
│                    DATA FETCHING COMPARISON                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  useAsyncData                                                        │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                                                             │   │
│  │  const { data, pending, error, refresh } = await useAsyncData(│   │
│  │    'key',                                                   │   │
│  │    () => $fetch('/api/data'),                               │   │
│  │    { transform, pick, default: () => [] }                  │   │
│  │  )                                                          │   │
│  │                                                             │   │
│  │  ✅ Manual fetch function                                    │   │
│  │  ✅ Full control over fetch options                          │   │
│  │  ✅ Better for complex data transformations                 │   │
│  │  ✅ SSR-safe with caching                                    │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  useFetch                                                           │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                                                             │   │
│  │  const { data, pending, error } = await useFetch('/api/data', │   │
│  │    {                                                      │   │
│  │      method: 'GET',                                       │   │
│  │      query: { limit: 10 },                                │   │
│  │      headers: { Authorization: token },                   │   │
│  │    }                                                       │   │
│  │  )                                                          │   │
│  │                                                             │   │
│  │  ✅ Simpler syntax                                          │   │
│  │  ✅ Auto-generates key from URL                             │   │
│  │  ✅ Type-safe với generics                                  │   │
│  │  ✅ SSR-safe                                                │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 5. Server Engine

### 5.1 Nitro Server Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        NITRO SERVER ENGINE                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    Server Directory                          │   │
│  │                                                             │   │
│  │  server/                                                   │   │
│  │  ├── api/          # REST API routes                        │   │
│  │  ├── routes/       # Non-API routes (health, sitemap)       │   │
│  │  ├── middleware/   # Server-wide middleware                 │   │
│  │  ├── plugins/      # Server plugins (database, cache)      │   │
│  │  └── utils/        # Server utilities                       │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    Request Lifecycle                          │   │
│  │                                                             │   │
│  │  Request ─► CORS ─► Auth ─► Route Handler ─► Response     │   │
│  │    │         │       │           │                          │   │
│  │    │         │       │           ▼                          │   │
│  │    │         │       │    ┌─────────────┐                   │   │
│  │    │         │       │    │  Database   │                   │   │
│  │    │         │       │    │   Query     │                   │   │
│  │    │         │       │    └─────────────┘                   │   │
│  │    │         │       │                                      │   │
│  │    │         │       ▼                                      │   │
│  │    │         │    ┌─────────────┐                           │   │
│  │    │         │    │   Cache    │                           │   │
│  │    │         │    │   Check    │                           │   │
│  │    │         │    └─────────────┘                           │   │
│  │    │         │                                              │   │
│  │    └─────────┘                                              │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 5.2 API Route Examples

```typescript
// server/api/users/index.get.ts
export default defineEventHandler(async (event) => {
  const query = getQuery(event);
  const users = await db.user.findMany({
    where: query.category ? { category: query.category } : undefined,
    take: Number(query.limit) || 10,
    orderBy: { createdAt: 'desc' },
  });
  
  return { users };
});

// server/api/users/index.post.ts
export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  
  // Validate với Zod hoặc similar
  const user = await db.user.create({
    data: {
      name: body.name,
      email: body.email,
    },
  });
  
  setResponseStatus(event, 201);
  return { user };
});

// server/api/users/[id].get.ts
export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id');
  
  const user = await db.user.findUnique({ where: { id } });
  
  if (!user) {
    throw createError({
      statusCode: 404,
      message: 'User not found',
    });
  }
  
  return { user };
});
```

---

## 6. State Management

### 6.1 State Options Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                      STATE MANAGEMENT OPTIONS                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  useState                                                           │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  SSR-safe, simple state, auto-imported                      │   │
│  │                                                             │   │
│  │  const count = useState('count', () => 0);                 │   │
│  │  const user = useState('user', () => null);                │   │
│  │                                                             │   │
│  │  ✅ SSR-safe (serialized to payload)                        │   │
│  │  ✅ Auto-imported                                           │   │
│  │  ✅ Simple for basic state                                  │   │
│  │  ❌ No built-in devtools                                    │   │
│  │  ❌ Limited for complex state                               │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  Pinia (with @pinia/nuxt)                                           │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  Full-featured state management                              │   │
│  │                                                             │   │
│  │  export const useUserStore = defineStore('user', () => {    │   │
│  │    const user = ref(null);                                  │   │
│  │    const isAuthenticated = computed(() => !!user.value);    │   │
│  │    async function login(credentials) { ... }                │   │
│  │    return { user, isAuthenticated, login };                  │   │
│  │  });                                                         │   │
│  │                                                             │   │
│  │  ✅ Full devtools support                                   │   │
│  │  ✅ Type-safe                                               │   │
│  │  ✅ Powerful for complex state                              │   │
│  │  ✅ Hydration support                                       │   │
│  │  ❌ Requires module installation                            │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  useCookie                                                         │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  Persistent state in browser cookies                        │   │
│  │                                                             │   │
│  │  const token = useCookie('auth-token', {                    │   │
│  │    maxAge: 60 * 60 * 24 * 7,                               │   │
│  │    secure: true,                                           │   │
│  │    httpOnly: true,                                         │   │
│  │  });                                                        │   │
│  │                                                             │   │
│  │  ✅ Persistent across sessions                              │   │
│  │  ✅ SSR-safe (synced server-client)                         │   │
│  │  ✅ Good for auth tokens                                    │   │
│  │  ❌ Limited storage size                                    │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 7. Module System

### 7.1 Module Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         NUXT MODULES                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  nuxt.config.ts                                                     │
│       │                                                             │
│       ▼                                                             │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    Module Registry                           │   │
│  │                                                             │   │
│  │  modules: [                                                │   │
│  │    '@pinia/nuxt',      // State management                  │   │
│  │    '@nuxt/image',      // Image optimization                │   │
│  │    '@vueuse/nuxt',     // VueUse composables                │   │
│  │    '@nuxtjs/i18n',     // Internationalization              │   │
│  │    'my-custom-module', // Custom module                     │   │
│  │  ]                                                          │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    Module Hooks                              │   │
│  │                                                             │   │
│  │  • nuxt:config:extend    - Modify config                   │   │
│  │  • build:config          - Modify webpack/vite config      │   │
│  │  • components:dirs       - Add component directories       │   │
│  │  • layouts:specify       - Specify layout files             │   │
│  │  • pages:extend          - Modify pages routes              │   │
│  │  • router:extend         - Modify router                   │   │
│  │  • vite:extend          - Extend Vite config               │   │
│  │  • app:resolve          - Resolve aliases                  │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Liên kết liên quan
- [Nuxt Glossary](./glossary.md)
- [Nuxt Best Practices](./best-practice.md)
- [Nuxt Anti-Patterns](./anti-pattern.md)
- [Nuxt Checklist](./checklist.md)
- [Nuxt FAQ](./faq.md)
- [Nuxt Decision Tree](./decision-tree.md)
