# Nuxt.js Best Practices - Các Thực Hành Tốt Nhất

## Mục lục
1. [Data Fetching](#1-data-fetching)
2. [State Management](#2-state-management)
3. [Components](#3-components)
4. [Server Routes](#4-server-routes)
5. [Performance](#5-performance)
6. [Security](#6-security)
7. [TypeScript](#7-typescript)
8. [Testing](#8-testing)

---

## 1. Data Fetching

### 1.1 Use useFetch for Simple Requests

**Mô tả**: useFetch là cách đơn giản nhất để fetch data trong Nuxt 3. Nó tự động handle caching, SSR, và type inference.

**Ví dụ**:
```vue
<script setup lang="ts">
// Simple GET request
const { data: users, pending, error, refresh } = await useFetch('/api/users', {
  query: { limit: 10, active: true },
  transform: (response) => response.users,
});

// Type-safe with generic
interface User {
  id: string;
  name: string;
  email: string;
}

const { data: user } = await useFetch<User>('/api/user/1');

// POST request
const { data: newUser } = await useFetch<User>('/api/users', {
  method: 'POST',
  body: { name: 'John', email: 'john@example.com' },
});
</script>
```

**Khi nào áp dụng**: Mọi simple API requests.

### 1.2 Use useAsyncData for Complex Logic

**Mô tả**: useAsyncData cho phép custom fetch logic và transformation, ideal cho complex data processing.

**Ví dụ**:
```vue
<script setup lang="ts">
const { data: dashboard } = await useAsyncData('dashboard', async () => {
  // Complex data fetching with multiple sources
  const [users, stats, recentActivity] = await Promise.all([
    $fetch('/api/users'),
    $fetch('/api/stats'),
    $fetch('/api/activity'),
  ]);
  
  return {
    totalUsers: users.length,
    activeUsers: users.filter(u => u.isActive).length,
    stats,
    recentActivity: recentActivity.slice(0, 5),
  };
}, {
  // Cache for 5 minutes
  ttl: 300000,
  // Transform data
  transform: (data) => ({
    ...data,
    formattedDate: new Date().toLocaleDateString('vi-VN'),
  }),
});
</script>
```

**Khi nào áp dụng**: Complex data transformations, multiple API calls.

### 1.3 Always Handle Loading and Error States

**Mô tả**: Cung cấp appropriate UI cho loading và error states để improve user experience.

**Ví dụ**:
```vue
<script setup>
const { data: posts, pending, error, refresh } = await useFetch('/api/posts');
</script>

<template>
  <!-- Loading state -->
  <div v-if="pending" class="loading">
    <SkeletonLoader />
  </div>
  
  <!-- Error state -->
  <div v-else-if="error" class="error">
    <p>Đã xảy ra lỗi: {{ error.message }}</p>
    <button @click="refresh">Thử lại</button>
  </div>
  
  <!-- Success state -->
  <div v-else-if="posts">
    <PostList :posts="posts" />
  </div>
</template>
```

**Khi nào áp dụng**: Mọi data fetching operations.

---

## 2. State Management

### 2.1 Use useState for Simple SSR-Safe State

**Mô tả**: useState là cách đơn giản để tạo SSR-safe reactive state được shared giữa components.

**Ví dụ**:
```typescript
// composables/useCounter.ts
export const useCounter = (initialValue = 0) => {
  const count = useState('counter', () => initialValue);
  
  const increment = () => count.value++;
  const decrement = () => count.value--;
  const reset = () => (count.value = initialValue);
  
  return {
    count: readonly(count),
    increment,
    decrement,
    reset,
  };
};

// Usage in multiple components - state is shared
const { count, increment } = useCounter(0);
```

**Khi nào áp dụng**: Simple state cần shared across components.

### 2.2 Use Pinia for Complex State

**Mô tả**: Pinia cung cấp full-featured state management với devtools support và powerful features.

**Ví dụ**:
```typescript
// stores/auth.ts
import { defineStore } from 'pinia';

interface User {
  id: string;
  name: string;
  email: string;
}

export const useAuthStore = defineStore('auth', () => {
  const user = ref<User | null>(null);
  const token = useCookie('auth-token');
  
  const isAuthenticated = computed(() => !!user.value);
  
  async function login(credentials: { email: string; password: string }) {
    const response = await $fetch<{ user: User; token: string }>('/api/auth/login', {
      method: 'POST',
      body: credentials,
    });
    
    user.value = response.user;
    token.value = response.token;
  }
  
  async function logout() {
    await $fetch('/api/auth/logout', { method: 'POST' });
    user.value = null;
    token.value = null;
  }
  
  return {
    user: readonly(user),
    isAuthenticated,
    login,
    logout,
  };
});
```

**Khi nào áp dụng**: Complex state với multiple operations.

### 2.3 Use Cookie for Persistent State

**Mô tả**: useCookie cung cấp SSR-safe cookie access với automatic serialization.

**Ví dụ**:
```vue
<script setup>
// Auth token
const authToken = useCookie('auth-token', {
  maxAge: 60 * 60 * 24 * 7, // 1 week
  secure: true,
  httpOnly: false, // Client-accessible
});

// Preferences
const theme = useCookie('theme', {
  default: () => 'light',
});
</script>
```

**Khi nào áp dụng**: Persistent user preferences, auth tokens.

---

## 3. Components

### 3.1 Leverage Auto-imports

**Mô tả**: Nuxt tự động import components và composables từ specified directories. Đặt components đúng nơi để tận dụng auto-imports.

**Ví dụ**:
```
components/
├── AppHeader.vue          # → <AppHeader />
├── ui/
│   └── Button.vue        # → <UiButton />
└── icons/
    └── Search.vue        # → <IconsSearch />
```

**Khi nào áp dụng**: Mọi components nên được auto-imported.

### 3.2 Use Dynamic Components for Lazy Loading

**Mô tả**: Lazy load heavy components để reduce initial bundle size.

**Ví dụ**:
```vue
<script setup>
import { defineAsyncComponent } from 'vue';

const HeavyChart = defineAsyncComponent(() => 
  import('~/components/HeavyChart.vue')
);

const Modal = defineAsyncComponent({
  loader: () => import('~/components/Modal.vue'),
  loadingComponent: LoadingSpinner,
  delay: 200,
});
</script>

<template>
  <HeavyChart v-if="showChart" />
  <Modal v-if="showModal" />
</template>
```

**Khi nào áp dụng**: Heavy components, modals, optional features.

### 3.3 Provide Fallback Components

**Mô tả**: Cung cấp fallback cho missing components hoặc data.

**Ví dụ**:
```vue
<!-- Automatic fallback with lazy placeholder -->
<template>
  <LazyClientOnlyComponent v-if="show" />
  
  <!-- With explicit fallback -->
  <Suspense>
    <template #default>
      <HeavyDataTable :data="data" />
    </template>
    <template #fallback>
      <TableSkeleton :rows="10" />
    </template>
  </Suspense>
</template>
```

**Khi nào áp dụng**: Components với async loading.

---

## 4. Server Routes

### 4.1 Structure API Routes Clearly

**Mô tả**: Tổ chức server routes theo REST conventions.

**Ví dụ**:
```
server/api/
├── users/
│   ├── index.get.ts       # GET /api/users - List users
│   ├── index.post.ts      # POST /api/users - Create user
│   └── [id].get.ts        # GET /api/users/:id - Get user
├── posts/
│   ├── index.get.ts       # GET /api/posts
│   └── [id]/
│       ├── index.get.ts    # GET /api/posts/:id
│       ├── index.put.ts    # PUT /api/posts/:id
│       └── index.delete.ts # DELETE /api/posts/:id
```

**Khi nào áp dụng**: Mọi server API routes.

### 4.2 Handle Errors Properly

**Mô tả**: Sử dụng createError để throw structured errors.

**Ví dụ**:
```typescript
// server/api/users/[id].get.ts
export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id');
  
  if (!id) {
    throw createError({
      statusCode: 400,
      message: 'User ID is required',
    });
  }
  
  const user = await db.user.findUnique({ where: { id } });
  
  if (!user) {
    throw createError({
      statusCode: 404,
      message: 'User not found',
    });
  }
  
  return { user };
});
```

**Khi nào áp dụng**: Mọi server routes.

### 4.3 Validate Input with Zod

**Mô tả**: Validate request body và params với Zod schema.

**Ví dụ**:
```typescript
import { z } from 'zod';

const createUserSchema = z.object({
  name: z.string().min(2, 'Tên phải có ít nhất 2 ký tự'),
  email: z.string().email('Email không hợp lệ'),
  age: z.number().optional(),
});

export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  
  const result = createUserSchema.safeParse(body);
  
  if (!result.success) {
    throw createError({
      statusCode: 400,
      message: result.error.issues[0].message,
    });
  }
  
  const user = await db.user.create({
    data: result.data,
  });
  
  return { user };
});
```

**Khi nào áp dụng**: API routes nhận user input.

---

## 5. Performance

### 5.1 Configure Route Rules

**Mô tả**: Sử dụng routeRules để optimize rendering cho từng route.

**Ví dụ**:
```typescript
// nuxt.config.ts
export default defineNuxtConfig({
  routeRules: {
    // Static generation
    '/': { prerender: true },
    '/about': { prerender: true },
    '/docs/**': { prerender: true },
    
    // ISR - revalidate every hour
    '/blog/**': { swr: 3600 },
    '/products/**': { swr: 1800 },
    
    // SSR for dynamic content
    '/profile/**': { ssr: true },
    '/api/**': { cors: true },
    
    // SPA mode
    '/dashboard/**': { ssr: false },
    '/settings/**': { ssr: false },
  },
});
```

**Khi nào áp dụng**: Production deployments.

### 5.2 Lazy Load Routes

**Mô tả**: Nuxt tự động lazy load routes, nhưng có thể optimize thêm.

**Ví dụ**:
```typescript
// nuxt.config.ts
export default defineNuxtConfig({
  experimental: {
    // Enable payload extraction for better SSR performance
    payloadExtraction: true,
  },
  
  app: {
    // Optimize head
    head: {
      link: [
        { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      ],
    },
  },
});
```

**Khi nào áp dụng**: Large applications.

### 5.3 Optimize Images

**Mô tả**: Sử dụng @nuxt/image để auto-optimize images.

**Ví dụ**:
```vue
<template>
  <NuxtImg
    src="/images/hero.jpg"
    alt="Hero image"
    width="1200"
    height="600"
    format="webp"
    loading="lazy"
    placeholder
  />
</template>
```

**Khi nào áp dụng**: Mọi images.

---

## 6. Security

### 6.1 Use Runtime Config for Secrets

**Mô tả**: Server-only secrets nên được đặt trong runtimeConfig.

**Ví dụ**:
```typescript
// nuxt.config.ts
export default defineNuxtConfig({
  runtimeConfig: {
    // Server-only (not exposed to client)
    databaseUrl: process.env.DATABASE_URL,
    apiSecret: process.env.API_SECRET,
    
    // Public (exposed to client)
    public: {
      apiBase: '/api',
      siteName: 'My Nuxt App',
    },
  },
});

// Server route
export default defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  // config.databaseUrl và config.apiSecret có sẵn
  // config.public.apiBase có sẵn
});
```

**Khi nào áp dụng**: Mọi secrets.

### 6.2 Validate Auth in Middleware

**Mô tả**: Implement authentication middleware cho protected routes.

**Ví dụ**:
```typescript
// middleware/auth.ts
export default defineNuxtRouteMiddleware((to) => {
  const user = useUser();
  
  if (!user.isAuthenticated) {
    return navigateTo({
      path: '/login',
      query: { redirect: to.fullPath },
    });
  }
});

// pages/admin.vue
definePageMeta({
  middleware: 'auth',
  // or for multiple middlewares
  middleware: ['auth', 'admin-only'],
});
```

**Khi nào áp dụng**: Protected routes.

### 6.3 Sanitize User Input

**Mô tả**: Validate và sanitize tất cả user input trong server routes.

**Ví dụ**:
```typescript
import DOMPurify from 'isomorphic-dompurify';

export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  
  // Sanitize HTML content
  if (body.bio) {
    body.bio = DOMPurify.sanitize(body.bio);
  }
  
  // Validate với Zod
  const schema = z.object({
    name: z.string().max(100),
    bio: z.string().max(500).optional(),
    email: z.string().email(),
  });
  
  const validated = schema.parse(body);
  
  // Process validated data
});
```

**Khi nào áp dụng**: User-generated content.

---

## 7. TypeScript

### 7.1 Enable Strict TypeScript

**Mô tả**: Configure TypeScript với strict mode.

**Ví dụ**:
```json
// tsconfig.json
{
  "extends": "./.nuxt/tsconfig.json",
  "compilerOptions": {
    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "types": ["@types/node"]
  }
}
```

**Khi nào áp dụng**: Mọi projects.

### 7.2 Type Server Routes

**Mô tả**: Export types từ server routes để reuse ở client.

**Ví dụ**:
```typescript
// server/api/users/index.get.ts
interface User {
  id: string;
  name: string;
  email: string;
  createdAt: Date;
}

export default defineEventHandler(async () => {
  const users = await db.user.findMany();
  return users;
});

// Re-export type for client usage
export type { User };
```

```vue
<script setup lang="ts">
// Import type from server route
import type { User } from '~/server/api/users/index.get';

const { data: users } = await useFetch<User[]>('/api/users');
</script>
```

**Khi nào áp dụng**: Shared types.

---

## 8. Testing

### 8.1 Unit Test Composables

**Mô tả**: Test composables với Vue Test Utils.

**Ví dụ**:
```typescript
// composables/__tests__/useCounter.test.ts
import { describe, it, expect } from 'vitest';
import { setupServer } from 'msw/node';
import { useCounter } from '../useCounter';

describe('useCounter', () => {
  it('increments count', () => {
    const { count, increment } = useCounter(0);
    
    increment();
    
    expect(count.value).toBe(1);
  });
  
  it('respects max value', () => {
    const { count, increment } = useCounter(10, { max: 10 });
    
    increment();
    
    expect(count.value).toBe(10);
  });
});
```

**Khi nào áp dụng**: Mọi composables.

### 8.2 E2E Test Pages

**Mô tả**: Test pages với Playwright.

**Ví dụ**:
```typescript
// e2e/home.test.ts
import { test, expect } from '@playwright/test';

test('homepage loads and shows content', async ({ page }) => {
  await page.goto('/');
  
  await expect(page.locator('h1')).toBeVisible();
  await expect(page.locator('nav')).toBeVisible();
});

test('navigation works', async ({ page }) => {
  await page.goto('/');
  
  await page.click('text=Products');
  
  await expect(page).toHaveURL('/products');
  await expect(page.locator('h1')).toContainText('Products');
});
```

**Khi nào áp dụng**: Critical user flows.

---

## Liên kết liên quan
- [Nuxt Glossary](./glossary.md)
- [Nuxt Architecture](./architecture.md)
- [Nuxt Anti-Patterns](./anti-pattern.md)
- [Nuxt Checklist](./checklist.md)
- [Nuxt FAQ](./faq.md)
- [Nuxt Decision Tree](./decision-tree.md)
