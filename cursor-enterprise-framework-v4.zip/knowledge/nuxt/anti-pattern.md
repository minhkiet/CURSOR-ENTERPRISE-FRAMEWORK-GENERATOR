# Nuxt.js Anti-Patterns - Các Mẫu Cần Tránh

## Mục lục
1. [Data Fetching Anti-Patterns](#1-data-fetching-anti-patterns)
2. [State Management Anti-Patterns](#2-state-management-anti-patterns)
3. [Component Anti-Patterns](#3-component-anti-patterns)
4. [Server Routes Anti-Patterns](#4-server-routes-anti-patterns)

---

## 1. Data Fetching Anti-Patterns

### 1.1 Double Fetching with useFetch

**Tên Pattern**: Client-Side Fetching

**Mô tả**: Sử dụng useFetch() trong script nhưng không await, dẫn đến fetching trên cả server và client.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
// ❌ BAD: Not awaited, will run on both server and client
const { data } = useFetch('/api/users');

console.log(data.value); // undefined on server!
</script>
```

**Hậu quả**:
- Double network requests
- Data không có sẵn trong initial HTML
- SEO issues
- Poor performance

**Giải pháp thay thế**:
```vue
<script setup>
// ✅ GOOD: Awaited, runs only on server, data available immediately
const { data } = await useFetch('/api/users');

console.log(data.value); // Available!
</script>
```

---

### 1.2 Not Using Cache Keys

**Tên Pattern**: Cache Key Missing

**Mô tả**: Không specify unique cache keys cho useAsyncData, dẫn đến potential caching conflicts.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
// ❌ BAD: Using dynamic key generation
const id = route.params.id;
const { data } = await useAsyncData(() => $fetch(`/api/users/${id}`));

// ✅ GOOD: Use unique, predictable keys
const { data } = await useAsyncData(`user-${route.params.id}`, () => 
  $fetch(`/api/users/${route.params.id}`)
);
</script>
```

**Hậu quả**:
- Caching conflicts
- Stale data
- Unpredictable behavior

---

### 1.3 Fetching in watchEffect Instead of useAsyncData

**Tên Pattern**: Inappropriate Fetch Trigger

**Mô tả**: Sử dụng watchEffect để trigger fetches thay vì useAsyncData's built-in revalidation.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
const searchQuery = ref('');

// ❌ BAD: Manual fetch in watchEffect
watchEffect(async () => {
  if (searchQuery.value) {
    const results = await $fetch(`/api/search?q=${searchQuery.value}`);
    searchResults.value = results;
  }
});

// ✅ GOOD: Use useFetch with watch
const { data: searchResults } = await useFetch('/api/search', {
  query: { q: searchQuery },
  watch: [searchQuery],
});
</script>
```

**Hậu quả**:
- Manual caching logic required
- Harder to manage loading/error states
- SSR complications

---

## 2. State Management Anti-Patterns

### 2.1 Using ref Instead of useState for SSR

**Tên Pattern**: Non-SSR State

**Mô tả**: Sử dụng ref() cho shared state thay vì useState(), dẫn đến hydration mismatches.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
// ❌ BAD: ref() is not SSR-safe for shared state
const user = ref(null);

onMounted(async () => {
  user.value = await $fetch('/api/user');
});
</script>
```

**Hậu quả**:
- Hydration mismatch
- Flash of unstyled content
- State loss on navigation

**Giải pháp thay thế**:
```vue
<script setup>
// ✅ GOOD: useState is SSR-safe
const user = await useAsyncData('user', () => $fetch('/api/user'));
</script>
```

---

### 2.2 Overusing useState for Everything

**Tên Pattern**: State Over-Engineering

**Mô tả**: Sử dụng useState cho mọi thứ, kể cả local-only state.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
// ❌ BAD: Using useState for local-only state
const isOpen = useState('isOpen', () => false);

// ✅ GOOD: Use ref for local-only state
const isOpen = ref(false);

// useState is for truly shared state across components
const isAuthenticated = useState('isAuthenticated', () => false);
</script>
```

**Hậu quả**:
- Unnecessary serialization overhead
- State pollution
- Confusing data flow

---

### 2.3 Mutating useState Without Replacing

**Tên Pattern**: Reactive Mutation

**Mô tả**: Thay đổi object properties trong useState thay vì replace entire state.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
const user = useState('user');

// ❌ BAD: Mutating nested properties
user.value.name = 'New Name'; // This might not trigger reactivity properly

// ✅ GOOD: Replace entire state
user.value = { ...user.value, name: 'New Name' };
</script>
```

**Hậu quả**:
- Unpredictable reactivity
- Potential state inconsistencies

---

## 3. Component Anti-Patterns

### 3.1 Not Using Built-in Components

**Tên Pattern**: Missing Built-in Components

**Mô tả**: Tự implement components đã có sẵn trong Nuxt ecosystem.

**Ví dụ (Anti-Pattern)**:
```vue
<!-- ❌ BAD: Custom skeleton loader -->
<div class="animate-pulse">
  <div class="h-4 bg-gray-200 rounded"></div>
</div>

<!-- ✅ GOOD: Use built-in Suspense -->
<Suspense>
  <template #default>
    <HeavyComponent />
  </template>
  <template #fallback>
    <SkeletonLoader />
  </template>
</Suspense>
```

**Hậu quả**:
- Duplicated code
- Inconsistent styling
- Miss out on optimizations

---

### 3.2 Blocking Hydration with Client-only Components

**Tên Pattern**: Hydration Blocking

**Mô tả**: Sử dụng ClientOnly cho nhiều content dẫn đến hydration issues.

**Ví dụ (Anti-Pattern)**:
```vue
<template>
  <!-- ❌ BAD: Wrapping too much content -->
  <ClientOnly>
    <AppHeader />
    <MainContent />
    <AppFooter />
  </ClientOnly>
</template>
```

**Hậu quả**:
- SEO issues
- Content not in initial HTML
- Hydration mismatch

**Giải pháp thay thế**:
```vue
<template>
  <AppHeader /> <!-- SSR-able -->
  <ClientOnly>
    <!-- Only client-specific content -->
    <UserPreferences />
    <IntercomWidget />
  </ClientOnly>
  <AppFooter />
</template>
```

---

### 3.3 Not Using definePageMeta

**Tên Pattern**: Missing Page Metadata

**Mô tả**: Không specify page metadata dẫn đến inconsistent behavior.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
// ❌ BAD: No metadata defined
const route = useRoute();
</script>

<template>
  <div>{{ route.params.id }}</div>
</template>
```

**Hậu quảả**:
- No SEO optimization
- No middleware protection
- Inconsistent routing

**Giải pháp thay thế**:
```vue
<script setup>
definePageMeta({
  middleware: 'auth',
  layout: 'custom',
});

useHead({
  title: 'Chi tiết sản phẩm',
  meta: [
    { name: 'description', content: 'Mô tả sản phẩm' },
  ],
});
</script>
```

---

## 4. Server Routes Anti-Patterns

### 4.1 Not Validating Input

**Tên Pattern**: Unvalidated Input

**Mô tả**: Không validate input trong server routes.

**Ví dụ (Anti-Pattern)**:
```typescript
// ❌ BAD: No validation
export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  
  // Directly use body without validation
  const user = await db.user.create({ data: body });
  
  return user;
});
```

**Hậu quả**:
- Security vulnerabilities
- Database errors
- Unexpected behavior

**Giải pháp thay thế**:
```typescript
import { z } from 'zod';

const createUserSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
});

export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  
  const result = createUserSchema.safeParse(body);
  if (!result.success) {
    throw createError({
      statusCode: 400,
      message: result.error.issues[0].message,
    });
  }
  
  const user = await db.user.create({ data: result.data });
  return user;
});
```

---

### 4.2 Exposing Internal Errors

**Tên Pattern**: Error Leakage

**Mô tả**: Trả về detailed error messages có thể expose internal information.

**Ví dụ (Anti-Pattern)**:
```typescript
// ❌ BAD: Exposing internal errors
export default defineEventHandler(async (event) => {
  try {
    return await someDatabaseOperation();
  } catch (error) {
    throw createError({
      statusCode: 500,
      message: error.message, // Exposes internal details!
      stack: error.stack,
    });
  }
});
```

**Hậu quả**:
- Information disclosure
- Security vulnerabilities
- Confusing error messages

**Giải pháp thay thế**:
```typescript
export default defineEventHandler(async (event) => {
  try {
    return await someDatabaseOperation();
  } catch (error) {
    console.error('Database error:', error); // Log internally
    
    throw createError({
      statusCode: 500,
      message: 'Internal server error',
    });
  }
});
```

---

### 4.3 Not Using Proper HTTP Methods

**Tên Pattern**: HTTP Method Mismatch

**Mô tả**: Sử dụng sai HTTP methods hoặc không phân biệt rõ ràng.

**Ví dụ (Anti-Pattern)**:
```typescript
// ❌ BAD: POST endpoint used for GET operations
export default defineEventHandler(async (event) => {
  const body = await readBody(event); // Expecting body for GET!
  
  return db.user.findMany();
});

// ✅ GOOD: Separate GET and POST
// server/api/users/index.get.ts
export default defineEventHandler(async () => {
  return db.user.findMany();
});

// server/api/users/index.post.ts
export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  return db.user.create({ data: body });
});
```

**Hậu quả**:
- Unexpected behavior
- API confusion
- Caching issues

---

## Liên kết liên quan
- [Nuxt Glossary](./glossary.md)
- [Nuxt Architecture](./architecture.md)
- [Nuxt Best Practices](./best-practice.md)
- [Nuxt Checklist](./checklist.md)
- [Nuxt FAQ](./faq.md)
- [Nuxt Decision Tree](./decision-tree.md)
