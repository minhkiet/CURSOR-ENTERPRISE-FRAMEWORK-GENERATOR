# Nuxt.js Glossary - Thuật Ngữ Chuyên Ngành

## Mục lục
1. [Nuxt Module](#1-nuxt-module)
2. [Auto-imports](#2-auto-imports)
3. [Server Routes](#3-server-routes)
4. [State Management](#4-state-management)
5. [Rendering Modes](#5-rendering-modes)
6. [Composables](#6-composables)
7. [Layouts và Pages](#7-layouts-và-pages)

---

## Nuxt Module

**Định nghĩa**: Nuxt Modules là các reusable packages mở rộng chức năng của Nuxt. Chúng có thể thêm plugins, webpack loaders, commands, và configuration options.

**Ví dụ**:
```typescript
// nuxt.config.ts
export default defineNuxtConfig({
  modules: [
    '@pinia/nuxt',          // State management
    '@nuxtjs/i18n',         // Internationalization
    '@nuxt/image',          // Image optimization
    '@vueuse/nuxt',         // VueUse composables
    '@nuxtjs/tailwindcss',  // Tailwind CSS
  ],
});
```

---

## Auto-imports

**Định nghĩa**: Nuxt tự động import và expose các Vue APIs, composables, utilities, và components mà không cần explicit imports. Điều này giúp giảm boilerplate code.

**Ví dụ**:
```vue
<script setup>
// Không cần import ref, computed, onMounted
const count = ref(0);  // Tự động available
const doubled = computed(() => count.value * 2);

onMounted(() => {
  console.log('Component mounted');
});

// Components trong components/ folder cũng auto-imported
</script>

<template>
  <MyComponent />  <!-- Không cần import -->
</template>
```

---

## Server Routes

**Định nghĩa**: Server Routes (server/api) là các server-side endpoints được viết bằng Nitro server engine. Chúng cho phép xử lý API requests trực tiếp trong Nuxt mà không cần external backend.

**Ví dụ**:
```typescript
// server/api/users/[id].get.ts
export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id');
  const user = await db.user.findUnique({
    where: { id },
  });
  
  if (!user) {
    throw createError({
      statusCode: 404,
      message: 'User not found',
    });
  }
  
  return user;
});
```

---

## useNuxt

**Định nghĩa**: useNuxt là built-in composable cung cấp access đến Nuxt instance. Nó được sử dụng trong composables và components để tương tác với Nuxt context.

**Ví dụ**:
```vue
<script setup>
const nuxtApp = useNuxtApp();

console.log(nuxtApp.isHydrating);
console.log(nuxtApp.payload);

nuxtApp.hook('page:finish', () => {
  console.log('Page finished loading');
});
</script>
```

---

## useRuntimeConfig

**Định nghĩa**: useRuntimeConfig cho phép truy cập configuration được define trong nuxt.config.ts. Runtime config được merge từ public và private sections.

**Ví dụ**:
```typescript
// nuxt.config.ts
export default defineNuxtConfig({
  runtimeConfig: {
    // Server-only (private)
    databaseUrl: process.env.DATABASE_URL,
    apiSecret: process.env.API_SECRET,
    
    // Public (client-accessible)
    public: {
      apiBase: '/api',
      siteName: 'My Nuxt App',
    },
  },
});

// Component
const config = useRuntimeConfig();

console.log(config.public.apiBase); // Client-accessible
console.log(config.databaseUrl);    // Server-only
```

---

## useAsyncData

**Định nghĩa**: useAsyncData là composable để fetch data bất đồng bộ với server-side rendering và caching support. Nó ngăn chặn double-fetching và cung cấp consistent state management.

**Ví dụ**:
```vue
<script setup>
// Fetch với SSR support
const { data: users, pending, error, refresh } = await useAsyncData(
  'users',  // Unique key for caching
  () => $fetch('/api/users'),  // Fetch function
  {
    transform: (data) => data.map(u => ({ ...u, name: u.name.toUpperCase() })),
    pick: ['id', 'name'],
  }
);

// Refresh data
refresh();
</script>
```

---

## useFetch

**Định nghĩa**: useFetch là wrapper around useAsyncData và $fetch, cung cấp declarative data fetching với automatic key generation và type inference.

**Ví dụ**:
```vue
<script setup>
// Simplified data fetching
const { data: posts, pending, error } = await useFetch('/api/posts', {
  query: { limit: 10, published: true },
  headers: { 'X-Custom': 'header' },
});

// Type-safe với generic
const { data: user } = await useFetch<User>('/api/user', {
  method: 'POST',
  body: { name: 'John' },
});
</script>
```

---

## useState

**Định nghĩa**: useState là composable tạo reactive state được shared giữa components và SSR-safe. State được serialized và hydrated trên client.

**Ví dụ**:
```vue
<script setup>
// SSR-safe shared state
const counter = useState('counter', () => 0);

counter.value++;
</script>

<template>
  <div>
    <p>Counter: {{ counter }}</p>
    <!-- State shared across components -->
  </div>
</template>
```

---

## definePageMeta

**Định nghĩa**: definePageMeta là macro định nghĩa metadata cho page như layout, middleware, transitions, và breadcrumb.

**Ví dụ**:
```vue
<script setup>
definePageMeta({
  layout: 'custom',
  middleware: ['auth'],
  transitions: {
    name: 'slide',
    mode: 'out-in',
  },
  validate: (route) => {
    return !isNaN(Number(route.params.id));
  },
});
</script>
```

---

## useHead

**Định nghĩa**: useHead là composable để quản lý HTML head tags như title, meta, link, và script từ trong components.

**Ví dụ**:
```vue
<script setup>
useHead({
  title: 'Trang chủ - My Nuxt App',
  meta: [
    { name: 'description', content: 'Mô tả trang web' },
    { property: 'og:title', content: 'Trang chủ' },
  ],
  link: [
    { rel: 'canonical', href: 'https://example.com' },
  ],
  script: [
    { type: 'application/ld+json', innerHTML: JSON.stringify({ /* schema */ }) },
  ],
});
</script>
```

---

## useRoute

**Định nghĩa**: useRoute là composable trả về current route object, cho phép access params, query, và route metadata.

**Ví dụ**:
```vue
<script setup>
const route = useRoute();

// Access route params
const id = route.params.id;

// Access query params
const search = route.query.search;

// Check route name
console.log(route.name);
</script>
```

---

## Middleware

**Định nghĩa**: Nuxt Middleware là functions chạy trước khi page được render. Có three types: route middleware, server middleware, và plugin middleware.

**Ví dụ**:
```typescript
// middleware/auth.ts
export default defineNuxtRouteMiddleware((to, from) => {
  const user = useUser();
  
  if (!user.isAuthenticated) {
    return navigateTo('/login');
  }
});

// Usage in page
definePageMeta({
  middleware: 'auth',
  // or inline array
  middleware: [authMiddleware, (to) => {
    if (to.path === '/admin') {
      return abortNavigation('Unauthorized');
    }
  }],
});
```

---

## Layouts

**Định nghĩa**: Layouts là wrappers xung quanh page content, cung cấp consistent UI structure như headers, footers, và sidebars.

**Ví dụ**:
```vue
<!-- layouts/default.vue -->
<template>
  <div>
    <AppHeader />
    <slot />  <!-- Page content rendered here -->
    <AppFooter />
  </div>
</template>

<!-- layouts/auth.vue -->
<template>
  <div class="auth-layout">
    <slot />
  </div>
</template>

<!-- Usage in page -->
<script setup>
definePageMeta({
  layout: 'auth',
});
</script>
```

---

## plugins

**Định nghĩa**: Plugins là functions được executed trước khi app mount, cho phép inject dependencies và register global features.

**Ví dụ**:
```typescript
// plugins/axios.ts
export default defineNuxtPlugin((nuxtApp) => {
  const config = useRuntimeConfig();
  
  const api = $fetch.create({
    baseURL: config.public.apiBase,
  });
  
  return {
    provide: {
      api,
    },
  };
});

// Usage
const { $api } = useNuxtApp();
```

---

## composables

**Định nghĩa**: Composables trong Nuxt được auto-imported từ composables/ directory và có thể sử dụng SSR-safe patterns.

**Ví dụ**:
```typescript
// composables/useCounter.ts
export const useCounter = (initialValue = 0) => {
  const count = useState('count', () => initialValue);
  
  const increment = () => count.value++;
  const decrement = () => count.value--;
  const reset = () => (count.value = initialValue);
  
  return {
    count: readonly(count),
    increment,
    decrement,
    reset,
  };
};
```

---

## nuxt.config

**Định nghĩa**: nuxt.config là file configuration chính cho Nuxt application, định nghĩa modules, app settings, rendering options, và build configuration.

**Ví dụ**:
```typescript
// nuxt.config.ts
export default defineNuxtConfig({
  devtools: { enabled: true },
  
  app: {
    head: {
      title: 'My Nuxt App',
      htmlAttrs: { lang: 'vi' },
    },
    pageTransition: { name: 'page', mode: 'out-in' },
  },
  
  modules: ['@pinia/nuxt'],
  
  css: ['~/assets/css/main.css'],
  
  routeRules: {
    '/': { prerender: true },
    '/dashboard/**': { ssr: false },
    '/api/**': { cors: true },
  },
});
```

---

## Liên kết liên quan
- [Nuxt Architecture](./architecture.md)
- [Nuxt Best Practices](./best-practice.md)
- [Nuxt Anti-Patterns](./anti-pattern.md)
- [Nuxt Checklist](./checklist.md)
- [Nuxt FAQ](./faq.md)
- [Nuxt Decision Tree](./decision-tree.md)
