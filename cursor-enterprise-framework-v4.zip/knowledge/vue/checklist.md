# Vue.js Checklist - Danh Sách Kiểm Tra

## Mục lục
1. [Project Setup](#1-project-setup)
2. [Components](#2-components)
3. [Composition API](#3-composition-api)
4. [State Management](#4-state-management)
5. [Vue Router](#5-vue-router)
6. [Performance](#6-performance)
7. [TypeScript](#7-typescript)
8. [Security](#8-security)
9. [Testing](#9-testing)
10. [Deployment](#10-deployment)

---

## 1. Project Setup

### 1.1 Initial Configuration

- [ ] Sử dụng Vue 3 với Composition API
- [ ] Cài đặt TypeScript
- [ ] Cấu hình Vite như build tool
- [ ] Cài đặt ESLint với Vue plugin
- [ ] Cài đặt Prettier
- [ ] Cấu hình path aliases (`@/` → `src/`)

### 1.2 Core Dependencies

- [ ] Vue Router cho routing
- [ ] Pinia cho state management
- [ ] Axios cho HTTP requests
- [ ] Zod cho validation (hoặc VeeValidate)

### 1.3 Development Tools

- [ ] Vue DevTools extension
- [ ] Volar extension (VS Code)
- [ ] Git hooks (Husky)
- [ ] EditorConfig

---

## 2. Components

### 2.1 Component Structure

- [ ] Sử dụng `<script setup>` syntax
- [ ] Define props với validation
- [ ] Define emits explicit
- [ ] Sử dụng `defineModel()` cho v-model
- [ ] Components có meaningful names

### 2.2 Component Communication

- [ ] Props là read-only
- [ ] Events được emit cho parent communication
- [ ] Sử dụng provide/inject cho deeply nested components
- [ ] Pinia cho cross-component state

### 2.3 Component Organization

- [ ] Single responsibility cho mỗi component
- [ ] Components được đặt gần nơi sử dụng
- [ ] Shared components trong `components/common/` hoặc `shared/components/`
- [ ] Feature-specific components trong feature folder

### 2.4 Template Guidelines

- [ ] Sử dụng semantic HTML elements
- [ ] Conditional rendering với v-if (not v-show khi unmount)
- [ ] List rendering với :key unique
- [ ] Attribute binding với `:`
- [ ] Event binding với `@`

---

## 3. Composition API

### 3.1 Reactivity

- [ ] Sử dụng `ref()` cho primitives
- [ ] Sử dụng `reactive()` cho objects
- [ ] Sử dụng `computed()` cho derived values
- [ ] Sử dụng `watch()`/`watchEffect()` cho side effects
- [ ] Tránh unnecessary reactive conversions

### 3.2 Lifecycle Hooks

- [ ] `onMounted()` cho initialization
- [ ] `onUnmounted()` cho cleanup
- [ ] `onBeforeUpdate()`/`onUpdated()` cho update tracking
- [ ] `onErrorCaptured()` cho error handling
- [ ] Cleanup subscriptions trong onUnmounted

### 3.3 Composables

- [ ] Logic reusable được extract thành composables
- [ ] Composables có typed return values
- [ ] Composables được test được
- [ ] Composables naming: `use*` pattern

### 3.4 Async Handling

- [ ] Loading states cho async operations
- [ ] Error handling cho failed requests
- [ ] Try-catch blocks cho async code
- [ ] finally block cho cleanup

---

## 4. State Management

### 4.1 Pinia Store Structure

- [ ] Mỗi feature có store riêng
- [ ] State được defined as function
- [ ] Getters cho computed state
- [ ] Actions cho async operations
- [ ] Stores được typed

### 4.2 Store Organization

```
stores/
├── auth.ts
├── products.ts
├── cart.ts
├── ui.ts
└── index.ts (optional barrel export)
```

### 4.3 Store Usage

- [ ] Stores được import khi cần
- [ ] Không store everything - chỉ cross-component state
- [ ] Store actions return promises cho async operations
- [ ] State updates là synchronous khi có thể

### 4.4 Persistence

- [ ] Sensitive data không được lưu trong localStorage
- [ ] Sử dụng encryption cho persisted sensitive data
- [ ] Cleanup khi logout/signout

---

## 5. Vue Router

### 5.1 Route Configuration

- [ ] Routes được defined trong typed array
- [ ] Lazy loading cho non-essential routes
- [ ] Route names được used consistently
- [ ] Route params được validated

### 5.2 Navigation Guards

- [ ] Authentication check với beforeEach
- [ ] Role-based access control
- [ ] Redirect logic cho authenticated/unauthenticated routes
- [ ] Meta fields cho route permissions

### 5.3 Route Organization

```
router/
├── index.ts
├── routes.ts
├── guards.ts
└── types.ts
```

### 5.4 Navigation

- [ ] Programmatic navigation với useRouter
- [ ] Route params accessed với route params
- [ ] Query params accessed với useRoute
- [ ] Scroll behavior configured

---

## 6. Performance

### 6.1 Component Performance

- [ ] Lazy load heavy components với defineAsyncComponent
- [ ] Sử dụng v-memo cho large lists
- [ ] Avoid unnecessary reactive conversions
- [ ] Use shallowRef/shallowReactive khi phù hợp

### 6.2 Bundle Optimization

- [ ] Code splitting theo routes
- [ ] Tree-shaking unused code
- [ ] External dependencies được minimized
- [ ] Bundle size được monitored

### 6.3 Rendering Optimization

- [ ] Components được memoized khi cần
- [ ] Avoid computed functions được called trong template
- [ ] Use functional components cho simple presentational components
- [ ] Pagination/infinite scroll cho large lists

### 6.4 Caching

- [ ] API responses được cached khi appropriate
- [ ] Computed properties được used thay vì methods
- [ ] Async components với loading states

---

## 7. TypeScript

### 7.1 Type Definitions

- [ ] Props được typed
- [ ] Emits được typed
- [ ] Reactive values được typed
- [ ] Store state và getters được typed

### 7.2 Type Organization

```
types/
├── index.ts
├── components/
│   └── *.d.ts
├── stores/
│   └── *.d.ts
└── api/
    └── *.d.ts
```

### 7.3 Type Safety

- [ ] No `any` types (unless absolutely necessary)
- [ ] Generic types được used khi appropriate
- [ ] Union types cho variant data
- [ ] Optional chaining được used

### 7.4 TypeScript Configuration

- [ ] Strict mode enabled
- [ ] NoImplicitAny: true
- [ ] StrictNullChecks: true
- [ ] Path aliases configured in tsconfig

---

## 8. Security

### 8.1 XSS Prevention

- [ ] Không sử dụng v-html với untrusted content
- [ ] User input được escaped
- [ ] Sanitize HTML content nếu cần v-html
- [ ] Content Security Policy headers

### 8.2 CSRF Protection

- [ ] CSRF tokens cho API requests
- [ ] SameSite cookies
- [ ] Origin validation

### 8.3 Authentication

- [ ] JWT tokens được stored securely
- [ ] Token refresh mechanism
- [ ] Session expiration handling
- [ ] Secure logout

### 8.4 Input Validation

- [ ] Server-side validation
- [ ] Client-side validation với Zod
- [ ] Form input sanitization
- [ ] File upload validation

---

## 9. Testing

### 9.1 Unit Tests

- [ ] Composables được tested
- [ ] Store actions được tested
- [ ] Utility functions được tested
- [ ] Validation functions được tested

### 9.2 Component Tests

- [ ] Rendering được tested
- [ ] User interactions được tested
- [ ] Props validation được tested
- [ ] Events được tested

### 9.3 Test Structure

```
tests/
├── unit/
│   ├── composables/
│   ├── stores/
│   └── utils/
├── component/
└── e2e/
```

### 9.4 Coverage

- [ ] Critical paths được covered
- [ ] Edge cases được tested
- [ ] Error handling được tested
- [ ] Coverage > 80% cho critical modules

---

## 10. Deployment

### 10.1 Build Configuration

- [ ] Production build được optimized
- [ ] Source maps configured cho debugging
- [ ] Environment variables được set
- [ ] Asset hashing enabled

### 10.2 Environment Variables

- [ ] VITE_* prefix cho client-side vars
- [ ] Sensitive data trong server-only env
- [ ] .env files cho different environments
- [ ] Runtime config cho dynamic values

### 10.3 Deployment Targets

- [ ] Vercel/Netlify cho static hosting
- [ ] Docker cho containerized deployment
- [ ] CI/CD pipeline configured
- [ ] Health checks implemented

### 10.4 Post-Deployment

- [ ] Error tracking configured (Sentry)
- [ ] Analytics configured
- [ ] Performance monitoring
- [ ] Uptime monitoring

---

## Quick Reference

### Component Checklist
```
[ ] <script setup> used
[ ] Props defined with validation
[ ] Emits defined
[ ] Meaningful name
[ ] Single responsibility
[ ] Properly typed
```

### Store Checklist
```
[ ] State defined as function
[ ] Getters for computed state
[ ] Actions for operations
[ ] Properly typed
[ ] Testable
```

### Router Checklist
```
[ ] Lazy loading configured
[ ] Navigation guards implemented
[ ] Route meta typed
[ ] Error routes handled
```

---

## Liên kết liên quan
- [Vue Glossary](./glossary.md)
- [Vue Architecture](./architecture.md)
- [Vue Best Practices](./best-practice.md)
- [Vue Anti-Patterns](./anti-pattern.md)
- [Vue FAQ](./faq.md)
- [Vue Decision Tree](./decision-tree.md)
