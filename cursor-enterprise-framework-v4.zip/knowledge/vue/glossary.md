# Vue.js Glossary - Thuật Ngữ Chuyên Ngành

## Mục lục
1. [Reactivity System](#1-reactivity-system)
2. [Components](#2-components)
3. [Directives](#3-directives)
4. [Routing](#4-routing)
5. [State Management](#5-state-management)
6. [Lifecycle Hooks](#6-lifecycle-hooks)
7. [Composition API](#7-composition-api)
8. [Build Tools](#8-build-tools)

---

## Reactive

**Định nghĩa**: Reactive là hệ thống theo dõi thay đổi của data trong Vue. Khi data thay đổi, Vue tự động cập nhật DOM tương ứng mà không cần manual manipulation.

**Ví dụ**:
```javascript
import { reactive } from 'vue';

const state = reactive({
  count: 0,
  message: 'Hello Vue',
});

function increment() {
  state.count++;
}
// Khi count thay đổi, DOM tự động update
```

---

## Ref

**Định nghĩa**: Ref là một function tạo ra reactive reference cho primitive values. Với objects, nên dùng reactive thay vì ref.

**Ví dụ**:
```javascript
import { ref } from 'vue';

const count = ref(0);
console.log(count.value); // 0

count.value++;
console.log(count.value); // 1
```

---

## Computed Properties

**Định nghĩa**: Computed properties là các thuộc tính được tính toán dựa trên reactive dependencies. Chúng được cache lại và chỉ re-compute khi dependencies thay đổi.

**Ví dụ**:
```javascript
import { ref, computed } from 'vue';

const firstName = ref('Nguyễn');
const lastName = ref('Văn');

const fullName = computed(() => {
  return `${lastName.value} ${firstName.value}`;
});
// fullName sẽ tự động update khi firstName hoặc lastName thay đổi
```

---

## Watchers

**Định nghĩa**: Watchers cho phép thực hiện side effects khi reactive state thay đổi. Phù hợp cho các operations như API calls, DOM manipulations.

**Ví dụ**:
```javascript
import { ref, watch } from 'vue';

const question = ref('');
const answer = ref('');

watch(question, async (newQuestion) => {
  if (newQuestion.includes('?')) {
    answer.value = 'Đang suy nghĩ...';
    const response = await fetch(`/api/ask?q=${newQuestion}`);
    answer.value = await response.json();
  }
});
```

---

## Components

**Định nghĩa**: Components là reusable Vue instances với tên riêng. Chúng là khối building blocks cơ bản của Vue applications.

**Ví dụ**:
```javascript
// Define component
const ButtonCounter = {
  template: `
    <button @click="count++">
      Bạn đã click {{ count }} lần
    </button>
  `,
  data() {
    return {
      count: 0,
    };
  },
};

// Register và use
app.component('button-counter', ButtonCounter);
```

---

## Single File Component (SFC)

**Định nghĩa**: Single File Component là file có extension `.vue` chứa template, script, và styles trong một file duy nhất.

**Ví dụ**:
```vue
<template>
  <div class="card">
    <h2>{{ title }}</h2>
    <p>{{ content }}</p>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const title = ref('Vue.js');
const content = ref('Framework tiến bộ');
</script>

<style scoped>
.card {
  padding: 1rem;
  border-radius: 8px;
}
</style>
```

---

## Props

**Định nghĩa**: Props là cách để truyền data từ parent component xuống child component. Chúng là read-only và được khai báo trong child component.

**Ví dụ**:
```vue
<!-- Parent -->
<template>
  <ChildComponent 
    title="Tiêu đề" 
    :count="totalCount"
  />
</template>

<!-- Child -->
<script setup>
defineProps({
  title: String,
  count: {
    type: Number,
    required: true,
    default: 0,
  },
});
</script>
```

---

## Slots

**Định nghĩa**: Slots cho phép parent component inject content vào child component, tạo ra composition pattern linh hoạt.

**Ví dụ**:
```vue
<!-- Layout Component -->
<template>
  <div class="layout">
    <header><slot name="header">Default Header</slot></header>
    <main><slot></slot></main>
    <footer><slot name="footer"></slot></footer>
  </div>
</template>

<!-- Usage -->
<LayoutComponent>
  <template #header>Custom Header</template>
  <p>Nội dung chính</p>
  <template #footer>© 2024</template>
</LayoutComponent>
```

---

## Directives

**Định nghĩa**: Directives là những special attributes bắt đầu với `v-` prefix, cung cấp reactive behavior cho DOM elements.

**Ví dụ**:
```vue
<!-- v-bind - binding attributes -->
<a v-bind:href="url">Link</a>
<a :href="url">Short syntax</a>

<!-- v-if - conditional rendering -->
<p v-if="show">Hiển thị khi show = true</p>

<!-- v-for - list rendering -->
<li v-for="item in items" :key="item.id">{{ item.name }}</li>

<!-- v-on - event handling -->
<button v-on:click="handleClick">Click</button>
<button @click="handleClick">Short syntax</button>

<!-- v-model - two-way binding -->
<input v-model="message" />
```

---

## v-model

**Định nghĩa**: v-model tạo two-way binding giữa form inputs và application state. Nó kết hợp v-bind và v-on một cách tự động.

**Ví dụ**:
```vue
<script setup>
import { ref } from 'vue';

const username = ref('');
const email = ref('');
const subscribed = ref(false);
</script>

<template>
  <form>
    <input v-model="username" placeholder="Tên đăng nhập" />
    <input v-model="email" type="email" placeholder="Email" />
    <input v-model="subscribed" type="checkbox" />
  </form>
</template>
```

---

## Vue Router

**Định nghĩa**: Vue Router là official routing library cho Vue.js, cung cấp navigation, nested routes, route guards, và lazy loading.

**Ví dụ**:
```javascript
import { createRouter, createWebHistory } from 'vue-router';
import Home from './views/Home.vue';
import About from './views/About.vue';

const routes = [
  { path: '/', name: 'Home', component: Home },
  { path: '/about', name: 'About', component: About },
  { 
    path: '/user/:id', 
    component: User, 
    props: true 
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});
```

---

## Pinia

**Định nghĩa**: Pinia là official state management library cho Vue 3, thay thế cho Vuex. Nó cung cấp reactive stores với TypeScript support tốt.

**Ví dụ**:
```javascript
// stores/counter.js
import { defineStore } from 'pinia';

export const useCounterStore = defineStore('counter', {
  state: () => ({
    count: 0,
  }),
  getters: {
    doubleCount: (state) => state.count * 2,
  },
  actions: {
    increment() {
      this.count++;
    },
  },
});
```

---

## Composition API

**Định nghĩa**: Composition API là set of APIs cho phép import functions từ Vue để author components. Nó cung cấp cách tổ chức logic linh hoạt hơn so với Options API.

**Ví dụ**:
```vue
<script setup>
import { ref, computed, onMounted } from 'vue';

const count = ref(0);
const doubleCount = computed(() => count.value * 2);

function increment() {
  count.value++;
}

onMounted(() => {
  console.log('Component mounted');
});
</script>
```

---

## Lifecycle Hooks

**Định nghĩa**: Lifecycle hooks là methods được gọi tự động trong quá trình lifecycle của Vue instance, từ creation đến unmount.

**Ví dụ**:
```vue
<script setup>
import { onMounted, onUpdated, onUnmounted } from 'vue';

onMounted(() => {
  console.log('Component mounted');
});

onUpdated(() => {
  console.log('Component updated');
});

onUnmounted(() => {
  console.log('Component unmounted');
});
</script>
```

---

## Teleport

**Định nghĩa**: Teleport cho phép render component's template part vào một vị trí DOM khác, useful cho modals, tooltips.

**Ví dụ**:
```vue
<template>
  <button @click="showModal = true">Mở Modal</button>
  
  <Teleport to="body">
    <div v-if="showModal" class="modal">
      <p>Nội dung Modal</p>
      <button @click="showModal = false">Đóng</button>
    </div>
  </Teleport>
</template>
```

---

## Suspense

**Định nghĩa**: Suspense cho phép hiển thị fallback content trong khi chờ async components (đặc biệt là async setup() components) resolve.

**Ví dụ**:
```vue
<template>
  <Suspense>
    <template #default>
      <AsyncComponent />
    </template>
    <template #fallback>
      <LoadingSpinner />
    </template>
  </Suspense>
</template>
```

---

## Provide/Inject

**Định nghĩa**: Provide/Inject cho phép truyền data từ ancestor component đến descendant components mà không cần prop drilling qua every level.

**Ví dụ**:
```javascript
// Ancestor component
import { provide, ref } from 'vue';

const theme = ref('dark');
provide('theme', theme);

// Descendant component
import { inject } from 'vue';

const theme = inject('theme');
console.log(theme.value);
```

---

## Vite

**Định nghĩa**: Vite là next-generation build tool cho JavaScript projects, được recommend cho Vue 3 projects. Nó sử dụng ES modules native browser support.

**Ví dụ**:
```bash
# Tạo Vue project với Vite
npm create vite@latest my-vue-app -- --template vue

# Chạy development server
npm run dev

# Build cho production
npm run build
```

---

## Vue CLI

**Định nghĩa**: Vue CLI là Command Line Interface cho Vue.js development, cung cấp project scaffolding, plugins, và build configuration.

**Ví dụ**:
```bash
# Cài đặt Vue CLI
npm install -g @vue/cli

# Tạo project mới
vue create my-vue-app

# Thêm Vue Router
vue add router

# Thêm Pinia
vue add pinia
```

---

## Vuex

**Định nghĩa**: Vuex là state management pattern + library cho Vue.js applications (Vue 2). Vue 3 khuyến nghị sử dụng Pinia thay thế.

**Ví dụ**:
```javascript
import { createStore } from 'vuex';

export default createStore({
  state() {
    return {
      count: 0,
    };
  },
  mutations: {
    increment(state) {
      state.count++;
    },
  },
  actions: {
    async incrementAsync({ commit }) {
      await api.increment();
      commit('increment');
    },
  },
  getters: {
    doubleCount: (state) => state.count * 2,
  },
});
```

---

## Liên kết liên quan
- [Vue Architecture](./architecture.md)
- [Vue Best Practices](./best-practice.md)
- [Vue Anti-Patterns](./anti-pattern.md)
- [Vue Checklist](./checklist.md)
- [Vue FAQ](./faq.md)
- [Vue Decision Tree](./decision-tree.md)
