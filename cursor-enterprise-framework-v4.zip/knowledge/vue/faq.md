# Vue.js FAQ - Câu Hỏi Thường Gặp

## Mục lục
1. [Components](#1-components)
2. [Composition API](#2-composition-api)
3. [Reactivity](#3-reactivity)
4. [Vue Router](#4-vue-router)
5. [Pinia](#5-pinia)
6. [Performance](#6-performance)
7. [TypeScript](#7-typescript)
8. [Testing](#8-testing)
9. [Build & Deployment](#9-build--deployment)

---

## 1. Components

### Q1: Sự khác nhau giữa Options API và Composition API là gì?

**A:** Options API và Composition API là hai cách để author Vue components:

| Aspect | Options API | Composition API |
|--------|-------------|-----------------|
| Organization | Logic grouped by option type (data, methods, computed) | Logic grouped by feature |
| Reusability | Mixins | Composables |
| TypeScript | Limited support | Full TypeScript support |
| Flexibility | Fixed structure | More flexible |
| Learning curve | Easier for beginners | Steeper learning curve |

```vue
<!-- Options API -->
<script>
export default {
  data() {
    return { count: 0 };
  },
  computed: {
    doubleCount() {
      return this.count * 2;
    },
  },
  methods: {
    increment() {
      this.count++;
    },
  },
};
</script>

<!-- Composition API -->
<script setup>
import { ref, computed } from 'vue';

const count = ref(0);
const doubleCount = computed(() => count.value * 2);

function increment() {
  count.value++;
}
</script>
```

**Khuyến nghị**: Sử dụng Composition API với `<script setup>` cho tất cả projects mới.

### Q2: Khi nào nên sử dụng watch vs watchEffect?

**A:**

| Scenario | watch | watchEffect |
|----------|-------|-------------|
| Need explicit dependency | Yes | No |
| Want immediate callback | No (default) | Yes |
| Only track specific sources | Yes | No |
| Cleanup needed | Yes | Yes |

```vue
<script setup>
import { ref, watch, watchEffect } from 'vue';

const count = ref(0);
const name = ref('');

// watch: Chỉ chạy khi count thay đổi
watch(count, (newValue, oldValue) => {
  console.log(`Count changed from ${oldValue} to ${newValue}`);
});

// watchEffect: Tự động track tất cả reactive dependencies
watchEffect(() => {
  // Chạy ngay và mỗi khi count hoặc name thay đổi
  console.log(`User: ${name.value}, Count: ${count.value}`);
});
</script>
```

### Q3: Computed vs Methods khác nhau như thế nào?

**A:** Computed properties được cache dựa trên dependencies và chỉ re-compute khi dependencies thay đổi. Methods luôn chạy mỗi lần được gọi.

```vue
<script setup>
const items = ref([1, 2, 3, 4, 5]);

// Computed - cached, re-runs only when items changes
const filteredItems = computed(() => {
  return items.value.filter(i => i > 2);
});

// Method - runs every time called
function getFilteredItems() {
  return items.value.filter(i => i > 2);
}
</script>

<template>
  <!-- computed: Chỉ re-evaluate khi items thay đổi -->
  <div v-for="item in filteredItems">{{ item }}</div>
  
  <!-- method: Re-runs every render -->
  <div v-for="item in getFilteredItems()">{{ item }}</div>
</template>
```

**Quy tắc**: Dùng computed cho derived values, methods cho actions.

---

## 2. Composition API

### Q4: Làm thế nào để share logic giữa các components?

**A:** Sử dụng Composables (custom hooks pattern):

```typescript
// composables/useCounter.ts
import { ref, computed } from 'vue';

export function useCounter(initialValue = 0) {
  const count = ref(initialValue);
  
  const doubleCount = computed(() => count.value * 2);
  
  function increment() {
    count.value++;
  }
  
  function decrement() {
    count.value--;
  }
  
  function reset() {
    count.value = initialValue;
  }
  
  return {
    count,
    doubleCount,
    increment,
    decrement,
    reset,
  };
}

// Usage
<script setup>
import { useCounter } from '@/composables/useCounter';

const { count, increment, decrement } = useCounter(10);
</script>
```

### Q5: defineProps và defineEmits hoạt động như thế nào?

**A:** Đây là compiler macros chỉ có sẵn trong `<script setup>`:

```vue
<script setup>
// Basic syntax
const props = defineProps<{
  title: string;
  count?: number;
}>();

// With defaults
const props = withDefaults(defineProps<{
  title: string;
  count: number;
}>(), {
  count: 0,
});

// Emits
const emit = defineEmits<{
  (e: 'update', value: string): void;
  (e: 'submit', data: FormData): void;
}>();

// Usage
emit('update', 'new value');
emit('submit', formData);
</script>
```

### Q6: Sự khác nhau giữa ref và reactive?

**A:**

| Aspect | ref | reactive |
|--------|-----|----------|
| Value access | .value | Direct |
| Type support | All types | Objects/Arrays only |
| Reassignment | Yes (replace entire ref) | No (mutate properties) |
| Array/Collection | Works | Works |

```vue
<script setup>
import { ref, reactive } from 'vue';

// ref - cho primitives và reassignment
const count = ref(0);
const user = ref({ name: 'John' }); // ref cho objects cũng được

count.value = 1;
user.value = { name: 'Jane' }; // reassign được

// reactive - chỉ cho objects
const state = reactive({
  count: 0,
  user: { name: 'John' },
});

state.count = 1;
state.user.name = 'Jane'; // mutate được
// state = { ... } // ❌ Không reassign được
</script>
```

---

## 3. Reactivity

### Q7: Tại sao ref cần .value?

**A:** Trong JavaScript, refs là objects với một property `value`. `.value` là nơi reactive data được stored. Trong templates, Vue tự động unwrap refs nên không cần `.value`.

```vue
<script setup>
import { ref } from 'vue';

const count = ref(0);

// JavaScript: Cần .value
console.log(count.value); // 0
count.value++;

// Template: Vue tự unwrap
</script>

<template>
  <!-- Không cần count.value trong template -->
  <p>{{ count }}</p>
</template>
```

### Q8: Làm thế nào để watch nhiều sources?

**A:** Sử dụng array syntax hoặc watchEffect:

```vue
<script setup>
import { ref, watch } from 'vue';

const firstName = ref('');
const lastName = ref('');

// Watch multiple refs
watch([firstName, lastName], ([newFirst, newLast], [oldFirst, oldLast]) => {
  console.log(`Name changed: ${oldFirst} ${oldLast} -> ${newFirst} ${newLast}`);
});

// Watch reactive object
const user = reactive({ firstName: '', lastName: '' });

watch(
  () => [user.firstName, user.lastName],
  ([newFirst, newLast]) => {
    console.log(`Name: ${newFirst} ${newLast}`);
  }
);
</script>
```

### Q9: shallowRef và shallowReactive khác nhau thế nào?

**A:** Shallow versions chỉ track top-level reactivity:

```vue
<script setup>
import { ref, shallowRef, reactive, shallowReactive } from 'vue';

// ref: Tracks .value changes
const count = ref(0);

// shallowRef: Chỉ track assignment to .value
const state = shallowRef({ 
  nested: { count: 0 } 
});
state.value.nested.count++; // ⚠️ Không trigger update!
state.value = { nested: { count: 1 } }; // ✅ Trigger update

// reactive: Deep reactivity
const state1 = reactive({ nested: { count: 0 } });
state1.nested.count++; // ✅ Update

// shallowReactive: Chỉ top-level
const state2 = shallowReactive({ nested: { count: 0 } });
state2.nested.count++; // ⚠️ Không trigger update!
state2.nested = { count: 1 }; // ✅ Trigger update
</script>
```

---

## 4. Vue Router

### Q10: Làm thế nào để lazy load routes?

**A:** Sử dụng dynamic imports:

```typescript
// router/index.ts
import { createRouter, createWebHistory } from 'vue-router';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/HomeView.vue'), // Lazy load
  },
  {
    path: '/products',
    name: 'Products',
    component: () => import('@/views/ProductsView.vue'),
  },
  {
    path: '/admin',
    name: 'Admin',
    component: () => import('@/views/AdminView.vue'),
    meta: { requiresAuth: true },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});
```

### Q11: Navigation guards hoạt động như thế nào?

**A:** Guards được gọi trong order:

```typescript
// router/index.ts
import { useAuthStore } from '@/stores/auth';

router.beforeEach(async (to, from, next) => {
  const authStore = useAuthStore();
  
  // Check if route requires auth
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next({ name: 'Login', query: { redirect: to.fullPath } });
    return;
  }
  
  // Check role
  if (to.meta.role && !authStore.hasRole(to.meta.role)) {
    next({ name: 'Unauthorized' });
    return;
  }
  
  next();
});

router.afterEach((to, from) => {
  // Analytics, scroll to top, etc.
});
```

---

## 5. Pinia

### Q12: Pinia vs Vuex - nên chọn cái nào?

**A:** **Pinia là lựa chọn khuyến nghị cho Vue 3:**

| Aspect | Pinia | Vuex |
|--------|-------|------|
| Vue 3 support | Native | Via plugin |
| TypeScript | Full support | Limited |
| Boilerplate | Less | More |
| DevTools | Supported | Supported |
| Size | Smaller | Larger |
| API | Simple | Complex |

### Q13: Làm thế nào để persist Pinia state?

**A:** Sử dụng pinia-plugin-persistedstate:

```typescript
// main.ts
import { createPinia } from 'pinia';
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';

const pinia = createPinia();
pinia.use(piniaPluginPersistedstate);

// store
export const useUserStore = defineStore('user', {
  state: () => ({
    name: 'John',
    preferences: {},
  }),
  persist: true, // Persist to localStorage
  // Or with options
  persist: {
    key: 'user-store',
    storage: localStorage,
    paths: ['name'], // Only persist name
  },
});
```

### Q14: Khi nào nên sử dụng Pinia thay vì local state?

**A:** Sử dụng Pinia khi:

- State cần được share giữa multiple components
- State cần persist qua page reloads
- State có complex logic (actions)
- Cần devtools support
- Testing cần access state

Sử dụng local state (ref/reactive) khi:

- State chỉ dùng trong một component
- State không cần share
- State là temporary (form inputs, UI state)

---

## 6. Performance

### Q15: Làm thế nào để optimize large lists?

**A:** Sử dụng virtualization hoặc pagination:

```vue
<script setup>
import { ref } from 'vue';

const items = ref(Array.from({ length: 10000 }, (_, i) => ({ id: i, name: `Item ${i}` })));
const page = ref(1);
const pageSize = 50;

const paginatedItems = computed(() => {
  const start = (page.value - 1) * pageSize;
  return items.value.slice(start, start + pageSize);
});

function nextPage() {
  if (page.value < Math.ceil(items.value.length / pageSize)) {
    page.value++;
  }
}
</script>

<template>
  <VirtualScroller :items="items" v-slot="{ item }">
    <ItemComponent :item="item" />
  </VirtualScroller>
  
  <!-- Hoặc pagination -->
  <div v-for="item in paginatedItems">
    <ItemComponent :item="item" />
  </div>
  <button @click="nextPage">Next</button>
</template>
```

### Q16: defineAsyncComponent hoạt động như thế nào?

**A:** Lazy load components:

```vue
<script setup>
import { defineAsyncComponent } from 'vue';
import LoadingSpinner from '@/components/LoadingSpinner.vue';

// Basic
const AsyncComponent = defineAsyncComponent(() =>
  import('@/components/HeavyComponent.vue')
);

// With options
const AsyncEditor = defineAsyncComponent({
  loader: () => import('@/components/RichTextEditor.vue'),
  loadingComponent: LoadingSpinner,
  delay: 200,
  timeout: 3000,
  onError(error, retry, fail, attempts) {
    if (attempts < 3) {
      retry();
    } else {
      fail();
    }
  },
});
</script>
```

---

## 7. TypeScript

### Q17: Làm thế nào để type reactive objects?

**A:** Sử dụng Interface/Type:

```typescript
interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
}

// Với ref
const user = ref<User | null>(null);

// Với reactive
const userState = reactive<User>({
  id: '',
  name: '',
  email: '',
  role: 'user',
});

// Computed types
const adminUsers = computed<User[]>(() => {
  return users.value.filter(u => u.role === 'admin');
});
```

### Q18: TypeScript với defineProps?

**A:** Sử dụng type-based declaration:

```typescript
// Basic
const props = defineProps<{
  title: string;
  count?: number;
  items: string[];
}>();

// Với defaults
const props = withDefaults(defineProps<{
  title: string;
  count?: number;
}>(), {
  count: 0,
});

// Với validator
const props = defineProps({
  title: {
    type: String,
    required: true,
  },
  status: {
    type: String as () => 'pending' | 'active' | 'completed',
    default: 'pending',
  },
});
```

---

## 8. Testing

### Q19: Làm thế nào để test composables?

**A:** Test composables trực tiếp với Vitest:

```typescript
// composables/__tests__/useCounter.test.ts
import { describe, it, expect } from 'vitest';
import { useCounter } from '../useCounter';

describe('useCounter', () => {
  it('increments count', () => {
    const { count, increment } = useCounter(0);
    expect(count.value).toBe(0);
    
    increment();
    expect(count.value).toBe(1);
  });
  
  it('decrements count', () => {
    const { count, decrement } = useCounter(5);
    decrement();
    expect(count.value).toBe(4);
  });
  
  it('resets to initial value', () => {
    const { count, increment, reset } = useCounter(10);
    increment();
    increment();
    reset();
    expect(count.value).toBe(10);
  });
});
```

### Q20: Component testing với Vue Test Utils?

**A:**

```typescript
// components/__tests__/Counter.test.ts
import { describe, it, expect } from 'vitest';
import { mount } from '@vue/test-utils';
import Counter from '../Counter.vue';

describe('Counter', () => {
  it('renders correctly', () => {
    const wrapper = mount(Counter, {
      props: { initialCount: 5 },
    });
    
    expect(wrapper.find('.count').text()).toBe('5');
  });
  
  it('increments when button clicked', async () => {
    const wrapper = mount(Counter);
    
    await wrapper.find('button.increment').trigger('click');
    
    expect(wrapper.find('.count').text()).toBe('1');
  });
  
  it('emits update event', async () => {
    const wrapper = mount(Counter);
    
    await wrapper.find('button.increment').trigger('click');
    
    expect(wrapper.emitted('update')).toBeTruthy();
    expect(wrapper.emitted('update')[0]).toEqual([1]);
  });
});
```

---

## 9. Build & Deployment

### Q21: Sự khác nhau giữa npm run dev và npm run build?

**A:**

| Command | Purpose | Output |
|---------|---------|--------|
| `npm run dev` | Development server với HMR | In-memory, no files |
| `npm run build` | Production build | Optimized files in `dist/` |
| `npm run preview` | Preview production build locally | Serves `dist/` |

### Q22: Environment variables hoạt động như thế nào?

**A:** Vue sử dụng Vite:

```bash
# .env - Default for all environments
VITE_APP_TITLE="My App"
VITE_API_URL="http://localhost:3000"

# .env.development - Development only
VITE_API_URL="http://localhost:8000"

# .env.production - Production only
VITE_API_URL="https://api.production.com"
```

```typescript
// Access in code
const appTitle = import.meta.env.VITE_APP_TITLE;
```

**Lưu ý**: Chỉ variables có prefix `VITE_` mới available ở client-side.

### Q23: SPA routing với deployment như thế nào?

**A:** SPA cần server configuration để handle client-side routing:

```nginx
# nginx.conf
server {
    listen 80;
    server_name example.com;
    root /var/www/app;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

---

## Liên kết liên quan
- [Vue Glossary](./glossary.md)
- [Vue Architecture](./architecture.md)
- [Vue Best Practices](./best-practice.md)
- [Vue Anti-Patterns](./anti-pattern.md)
- [Vue Checklist](./checklist.md)
- [Vue Decision Tree](./decision-tree.md)
