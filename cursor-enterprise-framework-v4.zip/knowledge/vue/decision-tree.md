# Vue.js Decision Tree - Cây Quyết Định

## Mục lục
1. [Component Type Decision](#1-component-type-decision)
2. [State Management Decision](#2-state-management-decision)
3. [Data Type Decision](#3-data-type-decision)
4. [Async Handling Decision](#4-async-handling-decision)
5. [Routing Decision](#5-routing-decision)
6. [Component Communication](#6-component-communication)
7. [Performance Optimization](#7-performance-optimization)

---

## 1. Component Type Decision

```
Bạn cần tạo component?
│
├── Component là presentational (chỉ hiển thị)?
│   ├── YES
│   │   └── Cần props input?
│   │       ├── YES ──────────────────────────────→ → → Presentational Component
│   │       │                                          └── Props only, no state
│   │       │
│   │       └── NO ─────────────────────────────────→ → → Static Component
│   │                                                              └── No props, no state
│   │
│   └── NO
│       │
│       └── Component có local state?
│           ├── YES
│           │   └── State phức tạp (multi-value)?
│           │       ├── YES ──────────────────────────────→ → → Full Component
│           │       │                                          └── State + logic + lifecycle
│           │       │
│           │       └── NO (single value) ────────────────→ → → Simple Stateful Component
│           │                                                              └── useState pattern
│           │
│           └── NO
│               │
│               └── Cần side effects (API calls, subscriptions)?
│                   ├── YES ──────────────────────────────→ → → Side Effect Component
│                   │                                          └── useEffect equivalent
│                   │
│                   └── NO ─────────────────────────────────→ → → Pure Presentational Component
│                                                                      └── Props → UI
```

---

## 2. State Management Decision

```
Bạn cần quản lý state?
│
├── State chỉ trong một component?
│   ├── YES ────────────────────────────────────────→ → → useState/ref
│   │                                                      └── const count = ref(0)
│   │
│   └── NO
│       │
│       └── State cần share giữa multiple components?
│           │
│           ├── Siblings hoặc parent-child?
│           │   ├── YES ──────────────────────────────→ → → Lift state up
│           │   │                                          └── State ở parent
│           │   │
│           │   └── NO
│           │       │
│           │       └── Deeply nested tree?
│           │           ├── YES ──────────────────────────────→ → → Provide/Inject
│           │           │                                          └── provide('key', value)
│           │           │
│           │           └── NO ──────────────────────────────→ → → Props drilling
│           │                                                              └── Truyền props
│           │
│           └── App-wide state?
│               ├── YES
│               │   └── State có async operations?
│               │       ├── YES ──────────────────────────────→ → → Pinia Store
│               │       │                                          └── Actions + state
│               │       │
│               │       └── NO ──────────────────────────────→ → → Pinia Store (simple)
│               │                                                              └── Reactive state
│               │
│               └── Persistent state?
│                   ├── YES ──────────────────────────────→ → → Pinia + Plugin
│                   │                                          └── pinia-plugin-persistedstate
│                   │
│                   └── NO ─────────────────────────────────→ → → Pinia Store
└── (End)
```

---

## 3. Data Type Decision

```
Bạn cần tạo reactive data?
│
├── Data là primitive value (string, number, boolean)?
│   ├── YES ────────────────────────────────────────→ → → ref()
│   │                                                      └── const count = ref(0)
│   │
│   └── NO
│       │
│       └── Data là object hoặc array?
│           │
│           ├── Bạn cần reassign entire object?
│           │   ├── YES ──────────────────────────────→ → → ref()
│           │   │                                          └── user.value = newUser
│           │   │
│           │   └── NO (chỉ mutate properties) ────────→ → → reactive()
│           │                                                      └── user.name = 'new name'
│           │
│           └── Data có nested objects?
│               │
│               ├── Cần deep reactivity?
│               │   ├── YES ──────────────────────────────→ → → reactive() hoặc ref()
│               │   │                                          └── Deep tracking
│               │   │
│               │   └── NO (chỉ top-level) ───────────────→ → → shallowReactive()
│               │                                                      └── shallowRef() cho ref
│               │
│               └── Performance critical?
│                   ├── YES ──────────────────────────────→ → → shallowRef()
│                   │                                          └── Chỉ track .value
│                   │
│                   └── NO ─────────────────────────────────→ → → ref() hoặc reactive()
│
└── (End)
```

---

## 4. Async Handling Decision

```
Bạn cần xử lý async operation?
│
├── Operation là trong setup() hoặc composable?
│   ├── YES
│   │   └── Operation cần chạy ngay?
│   │       ├── YES
│   │       │   └── Cần result persisted across renders?
│   │       │       ├── YES ──────────────────────────────→ → → ref() + await
│   │       │       │                                          └── const data = ref(null); onMounted(async () => { data.value = await fetch() })
│   │       │       │
│   │       │       └── NO ──────────────────────────────→ → → Chỉ cần await
│   │       │                                                              └── Trong setup đã async
│   │       │
│   │       └── NO (chạy sau mount) ────────────────────→ → → onMounted() + async
│   │                                                              └── onMounted(async () => { ... })
│   │
│   └── NO (triggers by user action)
│       │
│       └── Operation là event handler?
│           ├── YES ────────────────────────────────────→ → → async function + await
│           │                                              └── async function handleClick() { await save() }
│           │
│           └── NO ─────────────────────────────────────→ → → watchEffect()
└── (End)
```

---

## 5. Routing Decision

```
Bạn cần implement routing?
│
├── Route là essential (home, about)?
│   ├── YES ────────────────────────────────────────→ → → Static import
│   │                                                      └── import HomeView from '@/views/HomeView.vue'
│   │
│   └── NO
│       │
│       └── Route là secondary (admin, settings)?
│           ├── YES ────────────────────────────────→ → → Lazy import
│           │                                              └── component: () => import('@/views/Admin.vue')
│           │
│           └── Route là conditional (user-specific)?
│               ├── YES ────────────────────────────────→ → → Lazy import + Guard
│               │                                              └── component + meta: { requiresAuth: true }
│               │
│               └── NO ─────────────────────────────────→ → → Lazy import
│
└── Route cần authentication?
    ├── YES
    │   └── → → → Navigation guard
    │        └── router.beforeEach((to, from, next) => { ... })
    │
    └── NO
        └── (End)
```

---

## 6. Component Communication

```
Bạn cần communicate giữa components?
│
├── Parent → Child communication?
│   ├── YES ────────────────────────────────────────→ → → Props
│   │                                                      └── defineProps<{ title: string }>()
│   │
│   └── NO
│       │
│       └── Child → Parent communication?
│           ├── YES ─────────────────────────────────→ → → Emit
│           │                                              └── emit('event', payload)
│           │
│           └── Child ↔ Parent two-way?
│               ├── YES ─────────────────────────────────→ → → v-model / defineModel
│               │                                              └── const model = defineModel()
│               │
│               └── NO
│                   │
│                   └── Ancestor ↔ Descendant?
│                       ├── YES ────────────────────────────────→ → → Provide/Inject
│                       │                                              └── provide('key', value)
│                       │
│                       └── Siblings hoặc distant components?
│                           ├── YES ────────────────────────────────→ → → Pinia Store
│                           │                                              └── store pattern
│                           │
│                           └── Parent từ nhiều levels?
│                               └── → → → Provide/Inject (parent provides, deepest child injects)
```

---

## 7. Performance Optimization

```
Bạn cần optimize performance?
│
├── Có large list rendering?
│   ├── YES
│   │   └── List > 100 items?
│   │       ├── YES ────────────────────────────────→ → → Virtualization
│   │       │                                              └── vue-virtual-scroller
│   │       │
│   │       └── NO ─────────────────────────────────→ → → v-memo
│   │                                                              └── v-memo="[item.id]"
│   │
│   └── NO
│       │
│       └── Có heavy component (chart, editor)?
│           ├── YES ────────────────────────────────→ → → defineAsyncComponent
│           │                                              └── defineAsyncComponent(() => import(...))
│           │
│           └── NO
│               │
│               └── Có computed được recalculated thường xuyên?
│                   ├── YES ────────────────────────────────→ → → Check dependencies
│                   │                                              └── Computed dependencies
│                   │
│                   └── NO
│                       │
│                       └── Bundle size lớn?
│                           ├── YES ────────────────────────────────→ → → Code splitting
│                           │                                              └── Lazy routes
│                           │
│                           └── NO ─────────────────────────────────→ → → (No action needed)
```

---

## Quick Decision Reference

### Reactivity
```
Primitive (string, number) → ref()
Object/Array, reassign → ref()
Object/Array, mutate only → reactive()
Deep reactivity not needed → shallowRef()/shallowReactive()
```

### State Scope
```
Single component → useState/ref
Sibling/Parent-Child → Lift state
Deeply nested → Provide/Inject
App-wide → Pinia
```

### Async
```
Setup/composable → await hoặc onMounted
Event handler → async function
Computed side effects → watchEffect
```

### Component Type
```
Display only → Presentational
Display + local state → Stateful
Display + complex logic → Full component
Heavy component → Async component
```

### Route Loading
```
Essential → Static import
Secondary → Lazy import
Protected → Lazy + Guard
```

---

## Liên kết liên quan
- [Vue Glossary](./glossary.md)
- [Vue Architecture](./architecture.md)
- [Vue Best Practices](./best-practice.md)
- [Vue Anti-Patterns](./anti-pattern.md)
- [Vue Checklist](./checklist.md)
- [Vue FAQ](./faq.md)
