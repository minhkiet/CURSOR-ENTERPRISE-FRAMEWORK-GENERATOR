# Vue.js Architecture - Kiến Trúc Chi Tiết

## Mục lục
1. [Tổng quan Kiến trúc](#1-tổng-quan-kiến-trúc)
2. [Component Architecture](#2-component-architecture)
3. [Data Flow](#3-data-flow)
4. [Technology Stack](#4-technology-stack)
5. [Cấu trúc thư mục](#5-cấu-trúc-thư-mục)
6. [State Management](#6-state-management)
7. [Routing Architecture](#7-routing-architecture)
8. [Build & Deployment](#8-build--deployment)

---

## 1. Tổng quan Kiến trúc

### 1.1 Vue.js Overview

Vue.js là một progressive JavaScript framework để xây dựng user interfaces. Nó được thiết kế để adopt từng bước và có thể sử dụng cho cả small features lẫn complex enterprise applications.

Vue.js architecture bao gồm các core concepts:

- **Reactivity System**: Hệ thống tracking dependencies và updating DOM tự động
- **Component System**: Xây dựng ứng dụng từ reusable components
- **Template System**: Declarative rendering với HTML-based templates
- **Routing**: Client-side navigation với Vue Router
- **State Management**: Quản lý state toàn cục với Pinia

### 1.2 Vue.js Versions

| Version | Status | Key Features |
|---------|--------|--------------|
| Vue 2 | Maintenance | Options API, Vuex, Vue CLI |
| Vue 3 | Current | Composition API, Pinia, TypeScript support, Vite |
| Vue 3.5+ | Latest | Reactivity improvements, defineModel |

### 1.3 Architecture Principles

**Progressive**: Vue có thể được sử dụng như một library để enhance existing applications, hoặc như một full framework cho complete applications.

**Reactivity First**: Tất cả data changes được track và update một cách automatic, developers không cần manually manage DOM updates.

**Component-Based**: Mọi UI elements được encapsulate trong components, promote reusability và maintainability.

**Convention Over Configuration**: Vue follows sensible defaults nhưng cho phép customize khi cần.

---

## 2. Component Architecture

### 2.1 Component Types

```
┌─────────────────────────────────────────────────────────────────────┐
│                      COMPONENT HIERARCHY                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                     Root App Component                       │    │
│  │                    (App.vue / createApp)                     │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              │                                       │
│          ┌───────────────────┼───────────────────┐                   │
│          │                   │                   │                   │
│          ▼                   ▼                   ▼                   │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐          │
│  │   Layouts     │  │    Views      │  │   Shared      │          │
│  │  Components  │  │  (Pages)     │  │  Components   │          │
│  │               │  │               │  │               │          │
│  │ - AppHeader  │  │ - HomeView   │  │ - Button     │          │
│  │ - AppSidebar│  │ - AboutView  │  │ - Modal      │          │
│  │ - AppFooter │  │ - UserView   │  │ - Card       │          │
│  └───────────────┘  └───────────────┘  └───────────────┘          │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                    Feature Components                        │    │
│  │                                                               │    │
│  │  ┌───────────┐  ┌───────────┐  ┌───────────┐                │    │
│  │  │  User     │  │  Product  │  │   Order   │                │    │
│  │  │  List     │  │  Detail   │  │   Form    │                │    │
│  │  └───────────┘  └───────────┘  └───────────┘                │    │
│  │                                                               │    │
│  │  ┌───────────┐  ┌───────────┐  ┌───────────┐                │    │
│  │  │  User     │  │  Product  │  │   Order   │                │    │
│  │  │  Card     │  │  Card     │  │   Item    │                │    │
│  │  └───────────┘  └───────────┘  └───────────┘                │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 2.2 Component Communication Patterns

```
┌─────────────────────────────────────────────────────────────────────┐
│                   COMPONENT COMMUNICATION PATTERNS                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  Parent → Child: Props + Events                                      │
│  ┌──────────────────┐      props       ┌──────────────────┐        │
│  │   Parent         │ ────────────────► │   Child          │        │
│  │                  │ ◄──────────────── │                  │        │
│  │  @child-event   │      emit         │  this.$emit()    │        │
│  └──────────────────┘                   └──────────────────┘        │
│                                                                      │
│  Ancestor → Descendant: Provide/Inject                               │
│  ┌──────────────────┐                                                 │
│  │   Ancestor      │                                                 │
│  │                 │                                                 │
│  │ provide('key') │ ──────────┐                                     │
│  └──────────────────┘           │                                     │
│                    ┌────────────┼────────────┐                      │
│                    │            │            │                       │
│                    ▼            ▼            ▼                       │
│              ┌────────┐  ┌────────┐  ┌────────┐                    │
│              │Child 1 │  │Child 2 │  │Child 3 │                    │
│              │        │  │        │  │        │                    │
│              │inject()│  │inject()│  │inject()│                    │
│              └────────┘  └────────┘  └────────┘                    │
│                                                                      │
│  Global State: Pinia Store                                          │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │                      Pinia Store                               │   │
│  │                                                               │   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐         │   │
│  │  │  User   │  │ Product │  │  Cart   │  │  Auth   │         │   │
│  │  │  Store  │  │  Store  │  │  Store  │  │  Store  │         │   │
│  │  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘         │   │
│  └───────┼────────────┼────────────┼────────────┼───────────────┘   │
│          │            │            │            │                   │
│          ▼            ▼            ▼            ▼                   │
│      ┌───────┐  ┌───────┐  ┌───────┐  ┌───────┐                   │
│      │Component│  │Component│  │Component│  │Component│             │
│      └───────┘  └───────┘  └───────┘  └───────┘                   │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 2.3 Component Lifecycle

```
┌─────────────────────────────────────────────────────────────────────┐
│                       COMPONENT LIFECYCLE                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  Setup ──► Mount ──► Update ──► Unmount                           │
│    │          │         │         │                                │
│    │          │         │         │                                │
│    ▼          ▼         ▼         ▼                                │
│  ┌────┐   ┌───────┐ ┌────────┐ ┌───────────┐                      │
│  │    │   │       │ │        │ │           │                      │
│  │    │   │       │ │        │ │           │                      │
│  └────┘   └───────┘ └────────┘ └───────────┘                      │
│                                                                      │
│  Setup:                                                              │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  • beforeCreate (Vue 2)                                     │    │
│  │  • setup() (Composition API)                                │    │
│  │  • created (Vue 2)                                          │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
│  Mount:                                                              │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  • beforeMount                                               │    │
│  │  • mounted ← DOM ready, refs available                      │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
│  Update:                                                            │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  • beforeUpdate ← Before DOM re-render                      │    │
│  │  • updated ← After DOM re-render                           │    │
│  │  (triggered by reactive data changes)                       │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
│  Unmount:                                                           │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  • beforeUnmount ← Before removal                          │    │
│  │  • unmounted ← Cleanup complete                            │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 3. Data Flow

### 3.1 Vue Reactivity System

```
┌─────────────────────────────────────────────────────────────────────┐
│                    REACTIVITY SYSTEM FLOW                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                     Reactive Data                            │    │
│  │                                                               │    │
│  │  const state = reactive({                                    │    │
│  │    count: 0,                                                │    │
│  │    message: 'Hello'                                         │    │
│  │  })                                                          │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                   Dependency Tracking                        │    │
│  │                                                               │    │
│  │  When template accesses state.count:                         │    │
│  │  ┌─────────────────────────────────────────────────────────┐ │    │
│  │  │ <template>                                               │ │    │
│  │  │   <span>{{ state.count }}</span>  ← Tracks dependency  │ │    │
│  │  │ </template>                                              │ │    │
│  │  └─────────────────────────────────────────────────────────┘ │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                    Change Detection                          │    │
│  │                                                               │    │
│  │  state.count++                                                │    │
│  │       │                                                       │    │
│  │       ▼                                                       │    │
│  │  ┌─────────────────────────────────────────────────────────┐ │    │
│  │  │ Vue marks affected components as "dirty"                 │ │    │
│  │  └─────────────────────────────────────────────────────────┘ │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                    DOM Update                                │    │
│  │                                                               │    │
│  │  Vue queues component update                                  │    │
│  │  Virtual DOM diffing (if needed)                             │    │
│  │  Actual DOM patching                                         │    │
│  │                                                               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 3.2 Component Data Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│                    COMPONENT DATA FLOW                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│                         PARENT COMPONENT                            │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                                                             │    │
│  │  <ChildComponent                                           │    │
│  │    :title="pageTitle"       ◄─── Props (parent → child)    │    │
│  │    :items="productList"     ◄─── Props (parent → child)    │    │
│  │    @item-selected="handle"  ──── Events (child → parent)   │    │
│  │  />                                                      │    │
│  │                                                             │    │
│  │  const pageTitle = ref('Products');                       │    │
│  │  const productList = ref([]);                             │    │
│  │                                                             │    │
│  │  function handleSelect(item) {                            │    │
│  │    console.log('Selected:', item);                        │    │
│  │  }                                                        │    │
│  │                                                             │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              │                                       │
│                              │ props (:title, :items)                │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                     CHILD COMPONENT                           │    │
│  │                                                             │    │
│  │  <li v-for="item in items" @click="$emit('item-selected', item)"> │
│  │    {{ item.name }}                                          │    │
│  │  </li>                                                      │    │
│  │                                                             │    │
│  │  defineProps<{                                              │    │
│  │    title: string;                                           │    │
│  │    items: Item[];                                          │    │
│  │  }>();                                                     │    │
│  │                                                             │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 4. Technology Stack

### 4.1 Core Technologies

| Layer | Technology | Version | Purpose |
|-------|------------|---------|---------|
| Framework | Vue.js | 3.x | Core framework |
| Language | TypeScript | 5.x | Type safety |
| Build Tool | Vite | 5.x | Development & build |
| Routing | Vue Router | 4.x | Client-side routing |
| State | Pinia | 2.x | State management |
| Testing | Vitest | 1.x | Unit testing |
| E2E | Playwright | Latest | End-to-end testing |

### 4.2 Supporting Libraries

| Category | Library | Purpose |
|----------|---------|---------|
| HTTP Client | Axios | API calls |
| Forms | VeeValidate | Form validation |
| i18n | Vue I18n | Internationalization |
| Animation | Vue Transition | Transitions/animations |
| Validation | Zod | Schema validation |
| Icons | Heroicons | Icon library |

### 4.3 Development Tools

| Tool | Purpose |
|------|---------|
| Vue DevTools | Browser extension for debugging |
| ESLint | Code linting |
| Prettier | Code formatting |
| Volar | VS Code extension for Vue |

---

## 5. Cấu trúc thư mục

### 5.1 Standard Vue 3 Project Structure

```
project/
├── src/
│   ├── assets/                    # Static assets
│   │   ├── images/
│   │   └── styles/
│   │       ├── main.css
│   │       └── variables.css
│   │
│   ├── components/               # Shared components
│   │   ├── common/              # Generic UI components
│   │   │   ├── BaseButton.vue
│   │   │   ├── BaseInput.vue
│   │   │   ├── BaseModal.vue
│   │   │   ├── BaseCard.vue
│   │   │   └── BaseSpinner.vue
│   │   │
│   │   ├── layout/              # Layout components
│   │   │   ├── AppHeader.vue
│   │   │   ├── AppSidebar.vue
│   │   │   └── AppFooter.vue
│   │   │
│   │   └── forms/               # Form components
│   │       ├── SearchInput.vue
│   │       └── FilterSelect.vue
│   │
│   ├── composables/              # Reusable composition functions
│   │   ├── useAuth.ts
│   │   ├── useFetch.ts
│   │   ├── useDebounce.ts
│   │   └── useLocalStorage.ts
│   │
│   ├── views/                    # Page components (routes)
│   │   ├── HomeView.vue
│   │   ├── AboutView.vue
│   │   ├── auth/
│   │   │   ├── LoginView.vue
│   │   │   └── RegisterView.vue
│   │   └── dashboard/
│   │       ├── DashboardView.vue
│   │       └── SettingsView.vue
│   │
│   ├── router/                   # Vue Router configuration
│   │   ├── index.ts
│   │   └── routes.ts
│   │
│   ├── stores/                   # Pinia stores
│   │   ├── auth.ts
│   │   ├── cart.ts
│   │   ├── products.ts
│   │   └── ui.ts
│   │
│   ├── services/                  # API services
│   │   ├── api.ts               # Axios instance
│   │   ├── auth.service.ts
│   │   ├── product.service.ts
│   │   └── user.service.ts
│   │
│   ├── types/                    # TypeScript types
│   │   ├── index.ts
│   │   ├── user.ts
│   │   ├── product.ts
│   │   └── api.ts
│   │
│   ├── utils/                    # Utility functions
│   │   ├── formatters.ts
│   │   ├── validators.ts
│   │   └── constants.ts
│   │
│   ├── App.vue                    # Root component
│   └── main.ts                    # Application entry point
│
├── public/                        # Public static files
│   ├── favicon.ico
│   └── robots.txt
│
├── tests/                         # Test files
│   ├── unit/
│   └── e2e/
│
├── index.html                     # HTML entry point
├── vite.config.ts                 # Vite configuration
├── tsconfig.json                  # TypeScript configuration
├── eslint.config.js              # ESLint configuration
├── package.json
└── README.md
```

### 5.2 Feature-Based Structure (Alternative)

```
project/
├── src/
│   ├── features/
│   │   ├── auth/
│   │   │   ├── components/
│   │   │   │   ├── LoginForm.vue
│   │   │   │   ├── RegisterForm.vue
│   │   │   │   └── PasswordReset.vue
│   │   │   ├── composables/
│   │   │   │   └── useAuth.ts
│   │   │   ├── stores/
│   │   │   │   └── auth.ts
│   │   │   ├── views/
│   │   │   │   ├── LoginView.vue
│   │   │   │   └── RegisterView.vue
│   │   │   ├── types/
│   │   │   │   └── auth.ts
│   │   │   └── index.ts
│   │   │
│   │   ├── products/
│   │   │   ├── components/
│   │   │   │   ├── ProductList.vue
│   │   │   │   ├── ProductCard.vue
│   │   │   │   └── ProductFilter.vue
│   │   │   ├── composables/
│   │   │   │   └── useProducts.ts
│   │   │   ├── stores/
│   │   │   │   └── products.ts
│   │   │   ├── views/
│   │   │   │   ├── ProductListView.vue
│   │   │   │   └── ProductDetailView.vue
│   │   │   ├── types/
│   │   │   │   └── product.ts
│   │   │   └── index.ts
│   │   │
│   │   └── cart/
│   │       ├── components/
│   │       │   ├── CartDrawer.vue
│   │       │   └── CartItem.vue
│   │       ├── composables/
│   │       │   └── useCart.ts
│   │       ├── stores/
│   │       │   └── cart.ts
│   │       └── index.ts
│   │
│   ├── shared/                   # Shared code across features
│   │   ├── components/
│   │   │   └── ui/
│   │   ├── composables/
│   │   ├── types/
│   │   └── utils/
│   │
│   ├── router/
│   ├── App.vue
│   └── main.ts
```

---

## 6. State Management

### 6.1 Pinia Store Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                       PINIA STORE ARCHITECTURE                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                      APPLICATION                             │    │
│  │                                                             │    │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐       │    │
│  │  │ Auth    │  │ Products│  │  Cart   │  │   UI    │       │    │
│  │  │ Store   │  │  Store  │  │  Store  │  │  Store  │       │    │
│  │  └───┬─────┘  └───┬─────┘  └───┬─────┘  └───┬─────┘       │    │
│  │      │            │            │            │               │    │
│  │      └────────────┴─────┬──────┴────────────┘               │    │
│  │                         │                                     │    │
│  │                         ▼                                     │    │
│  │  ┌──────────────────────────────────────────────────────┐   │    │
│  │  │                  PINIA STORE                           │   │    │
│  │  │                                                       │   │    │
│  │  │  ┌───────────────┐  ┌───────────────┐                 │   │    │
│  │  │  │    STATE     │  │   GETTERS    │                 │   │    │
│  │  │  │               │  │               │                 │   │    │
│  │  │  │  {            │  │  {            │                 │   │    │
│  │  │  │    users: [], │  │   activeUser, │                 │   │    │
│  │  │  │    cart: [],  │  │   cartTotal,  │                 │   │    │
│  │  │  │    ui: {...}  │  │   isLoading   │                 │   │    │
│  │  │  │  }            │  │  }            │                 │   │    │
│  │  │  └───────────────┘  └───────────────┘                 │   │    │
│  │  │           │                │                         │   │    │
│  │  │           └────────┬───────┘                         │   │    │
│  │  │                    ▼                                  │   │    │
│  │  │  ┌───────────────────────────────────────────────┐   │   │    │
│  │  │  │                   ACTIONS                     │   │   │    │
│  │  │  │                                               │   │   │    │
│  │  │  │  async fetchUsers() { ... }                  │   │   │    │
│  │  │  │  addToCart(product) { ... }                 │   │   │    │
│  │  │  │  toggleSidebar() { ... }                    │   │   │    │
│  │  │  │                                               │   │   │    │
│  │  │  └───────────────────────────────────────────────┘   │   │    │
│  │  │                                                       │   │    │
│  │  └──────────────────────────────────────────────────────┘   │    │
│  │                                                             │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                     EXTERNAL SERVICES                        │    │
│  │                                                             │    │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐       │    │
│  │  │   API   │  │   API   │  │   API   │  │  Local  │       │    │
│  │  │ /users  │  │/products│  │ /orders │  │ Storage │       │    │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘       │    │
│  │                                                             │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 6.2 Store Definition Pattern

```typescript
// stores/products.ts
import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import type { Product } from '@/types/product';
import { productService } from '@/services/product.service';

export const useProductStore = defineStore('products', () => {
  // State
  const products = ref<Product[]>([]);
  const loading = ref(false);
  const error = ref<string | null>(null);
  const selectedCategory = ref<string | null>(null);

  // Getters
  const filteredProducts = computed(() => {
    if (!selectedCategory.value) return products.value;
    return products.value.filter(p => p.category === selectedCategory.value);
  });

  const categories = computed(() => {
    return [...new Set(products.value.map(p => p.category))];
  });

  const totalProducts = computed(() => products.value.length);

  // Actions
  async function fetchProducts() {
    loading.value = true;
    error.value = null;
    try {
      products.value = await productService.getAll();
    } catch (e) {
      error.value = 'Failed to fetch products';
      throw e;
    } finally {
      loading.value = false;
    }
  }

  async function fetchProduct(id: string) {
    loading.value = true;
    try {
      return await productService.getById(id);
    } finally {
      loading.value = false;
    }
  }

  function setCategory(category: string | null) {
    selectedCategory.value = category;
  }

  return {
    // State
    products,
    loading,
    error,
    selectedCategory,
    // Getters
    filteredProducts,
    categories,
    totalProducts,
    // Actions
    fetchProducts,
    fetchProduct,
    setCategory,
  };
});
```

---

## 7. Routing Architecture

### 7.1 Route Structure

```
┌─────────────────────────────────────────────────────────────────────┐
│                        ROUTE STRUCTURE                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                      Router Configuration                    │    │
│  │                                                             │    │
│  │  const routes = [                                           │    │
│  │    {                                                        │    │
│  │      path: '/',                                            │    │
│  │      name: 'home',                                         │    │
│  │      component: HomeView,                                   │    │
│  │    },                                                       │    │
│  │    {                                                        │    │
│  │      path: '/products',                                     │    │
│  │      component: ProductListView,                           │    │
│  │      children: [                                           │    │
│  │        { path: '', component: ProductGrid },               │    │
│  │        { path: ':id', component: ProductDetail },          │    │
│  │      ],                                                     │    │
│  │    },                                                       │    │
│  │    {                                                        │    │
│  │      path: '/admin',                                        │    │
│  │      component: AdminLayout,                               │    │
│  │      meta: { requiresAuth: true, role: 'admin' },         │    │
│  │      children: [                                           │    │
│  │        { path: 'dashboard', component: AdminDashboard },  │    │
│  │        { path: 'users', component: UserManagement },      │    │
│  │      ],                                                     │    │
│  │    },                                                       │    │
│  │  ]                                                          │    │
│  │                                                             │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### 7.2 Route Navigation Guards

```typescript
// router/guards.ts
import type { NavigationGuardNext, RouteLocationNormalized } from 'vue-router';
import { useAuthStore } from '@/stores/auth';

export async function requireAuth(
  to: RouteLocationNormalized,
  from: RouteLocationNormalized,
  next: NavigationGuardNext
) {
  const authStore = useAuthStore();
  
  if (!authStore.isAuthenticated) {
    next({
      name: 'login',
      query: { redirect: to.fullPath },
    });
    return;
  }
  
  // Check role if specified
  if (to.meta.role && !authStore.hasRole(to.meta.role as string)) {
    next({ name: 'unauthorized' });
    return;
  }
  
  next();
}

// router/index.ts
const router = createRouter({
  // ...
});

router.beforeEach(requireAuth);
```

---

## 8. Build & Deployment

### 8.1 Vite Build Configuration

```typescript
// vite.config.ts
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { fileURLToPath, URL } from 'node:url';

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: true,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['vue', 'vue-router', 'pinia'],
        },
      },
    },
  },
});
```

### 8.2 Deployment Options

```
┌─────────────────────────────────────────────────────────────────────┐
│                      DEPLOYMENT OPTIONS                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                      STATIC HOSTING                          │    │
│  │                                                               │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │    │
│  │  │  Vercel │  │ Netlify │  │Firebase │  │GitHub   │     │    │
│  │  │         │  │         │  │ Hosting │  │ Pages   │     │    │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘     │    │
│  │                                                               │    │
│  │  • Zero config deployment                                     │    │
│  │  • CDN for static assets                                      │    │
│  │  • Auto-scaling                                               │    │
│  │                                                               │    │
│  └───────────────────────────────────────────────────────────────┘    │
│                              │                                       │
│                              ▼                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                      CONTAINER DEPLOYMENT                    │    │
│  │                                                               │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │    │
│  │  │   Docker │  │    K8s   │  │  AWS     │  │  Azure   │   │    │
│  │  │          │  │          │  │  ECS     │  │ Container│   │    │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │    │
│  │                                                               │    │
│  │  • npm run build → dist/                                     │    │
│  │  • Serve dist/ with nginx or similar                         │    │
│  │  • SPA fallback configuration needed                          │    │
│  │                                                               │    │
│  └───────────────────────────────────────────────────────────────┘    │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

---

## Liên kết liên quan
- [Vue Glossary](./glossary.md)
- [Vue Best Practices](./best-practice.md)
- [Vue Anti-Patterns](./anti-pattern.md)
- [Vue Checklist](./checklist.md)
- [Vue FAQ](./faq.md)
- [Vue Decision Tree](./decision-tree.md)
