# Vue.js Best Practices - Các Thực Hành Tốt Nhất

## Mục lục
1. [Component Design](#1-component-design)
2. [Composition API](#2-composition-api)
3. [State Management](#3-state-management)
4. [Performance](#4-performance)
5. [TypeScript Usage](#5-typescript-usage)
6. [Testing](#6-testing)
7. [Security](#7-security)
8. [Code Organization](#8-code-organization)
9. [Vue Router](#9-vue-router)
10. [Build & Deployment](#10-build--deployment)

---

## 1. Component Design

### 1.1 Single Responsibility Principle

**Mô tả**: Mỗi component nên có một trách nhiệm duy nhất. Tách complex components thành smaller, focused components.

**Ví dụ**:
```vue
<!-- ❌ BAD: Component làm quá nhiều việc -->
<template>
  <div>
    <header>
      <input v-model="search" placeholder="Search" />
      <button @click="userMenuOpen = !userMenuOpen">{{ user.name }}</button>
    </header>
    <aside>
      <ul>
        <li v-for="item in menuItems">{{ item }}</li>
      </ul>
    </aside>
    <main>
      <div v-for="product in products">{{ product.name }}</div>
    </main>
  </div>
</template>

<!-- ✅ GOOD: Chia thành nhiều components -->
<template>
  <div>
    <AppHeader>
      <SearchInput v-model="search" />
      <UserMenu :user="user" />
    </AppHeader>
    <AppSidebar :items="menuItems" />
    <main>
      <ProductGrid :products="filteredProducts" />
    </main>
  </div>
</template>
```

**Khi nào áp dụng**: Áp dụng cho tất cả components để maintainability.

### 1.2 Props Validation

**Mô tả**: Luôn define props với validators để catch errors sớm và document component's expectations.

**Ví dụ**:
```vue
<script setup lang="ts">
const props = defineProps({
  // Basic type checking
  title: {
    type: String,
    required: true,
  },
  
  // Multiple types
  id: {
    type: [String, Number],
    required: true,
  },
  
  // With default
  count: {
    type: Number,
    default: 0,
  },
  
  // Object validation
  user: {
    type: Object as () => User,
    default: () => ({ name: 'Anonymous', age: 0 }),
  },
  
  // Array of values
  status: {
    type: String as () => 'pending' | 'active' | 'completed',
    default: 'pending',
  },
  
  // Custom validator
  items: {
    type: Array as () => Item[],
    validator: (items: Item[]) => items.every(i => i.id),
  },
});
</script>
```

**Khi nào áp dụng**: Mọi component nhận props từ parent.

### 1.3 Emits Validation

**Mô tả**: Khai báo emits để document và validate events mà component có thể emit.

**Ví dụ**:
```vue
<script setup lang="ts">
const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void;
  (e: 'submit', payload: FormData): void;
  (e: 'cancel'): void;
}>();

function handleSubmit() {
  emit('submit', { name: 'John', email: 'john@example.com' });
}

function handleCancel() {
  emit('cancel');
}
</script>
```

**Khi nào áp dụng**: Mọi component emit events lên parent.

---

## 2. Composition API

### 2.1 Use `<script setup>`

**Mô tả**: Sử dụng `<script setup>` syntax cho cleaner code và better performance.

**Ví dụ**:
```vue
<!-- ✅ GOOD: Using <script setup> -->
<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';

const count = ref(0);
const doubleCount = computed(() => count.value * 2);

onMounted(() => {
  console.log('Component mounted');
});

function increment() {
  count.value++;
}
</script>

<!-- ❌ AVOID: Regular script -->
<script lang="ts">
export default {
  setup() {
    const count = ref(0);
    const doubleCount = computed(() => count.value * 2);
    onMounted(() => {
      console.log('Component mounted');
    });
    function increment() {
      count.value++;
    }
    return { count, doubleCount, increment };
  },
};
</script>
```

**Khi nào áp dụng**: Sử dụng `<script setup>` cho tất cả Vue 3 components.

### 2.2 Composables Pattern

**Mô tả**: Extract reusable logic vào composables (custom hooks) để share giữa components.

**Ví dụ**:
```typescript
// composables/useLocalStorage.ts
import { ref, watch } from 'vue';

export function useLocalStorage<T>(key: string, defaultValue: T) {
  const stored = localStorage.getItem(key);
  const data = ref<T>(stored ? JSON.parse(stored) : defaultValue);
  
  watch(data, (newValue) => {
    localStorage.setItem(key, JSON.stringify(newValue));
  }, { deep: true });
  
  return data;
}

// Usage
<script setup>
import { useLocalStorage } from '@/composables/useLocalStorage';

const theme = useLocalStorage('theme', 'light');
</script>
```

**Khi nào áp dụng**: Khi có logic được reuse giữa nhiều components.

### 2.3 Proper Async Handling

**Mô tả**: Handle async operations properly với loading states và error handling.

**Ví dụ**:
```vue
<script setup lang="ts">
import { ref } from 'vue';

const data = ref<Data | null>(null);
const loading = ref(false);
const error = ref<string | null>(null);

async function fetchData() {
  loading.value = true;
  error.value = null;
  
  try {
    data.value = await api.fetchData();
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Unknown error';
  } finally {
    loading.value = false;
  }
}
</script>

<template>
  <div v-if="loading">
    <Spinner />
  </div>
  <div v-else-if="error" class="error">
    {{ error }}
    <button @click="fetchData">Thử lại</button>
  </div>
  <div v-else-if="data">
    <!-- Render data -->
  </div>
</template>
```

**Khi nào áp dụng**: Mọi async operations trong components.

---

## 3. State Management

### 3.1 Pinia Store Structure

**Mô tả**: Tổ chức Pinia stores một cách có cấu trúc với clear separation giữa state, getters, và actions.

**Ví dụ**:
```typescript
// stores/auth.ts
import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import type { User, LoginCredentials } from '@/types/auth';
import { authService } from '@/services/auth.service';

export const useAuthStore = defineStore('auth', () => {
  // === State ===
  const user = ref<User | null>(null);
  const token = ref<string | null>(null);
  const loading = ref(false);

  // === Getters ===
  const isAuthenticated = computed(() => !!token.value);
  const userName = computed(() => user.value?.name ?? 'Guest');
  const isAdmin = computed(() => user.value?.role === 'admin');

  // === Actions ===
  async function login(credentials: LoginCredentials) {
    loading.value = true;
    try {
      const response = await authService.login(credentials);
      token.value = response.token;
      user.value = response.user;
      return { success: true };
    } catch (error) {
      return { success: false, error };
    } finally {
      loading.value = false;
    }
  }

  async function logout() {
    token.value = null;
    user.value = null;
    await authService.logout();
  }

  return {
    // Expose state
    user,
    token,
    loading,
    // Expose getters
    isAuthenticated,
    userName,
    isAdmin,
    // Expose actions
    login,
    logout,
  };
});
```

**Khi nào áp dụng**: Khi cần share state giữa multiple components.

### 3.2 Modular Store Organization

**Mô tả**: Chia stores theo domain/features thay vì một monolithic store.

**Ví dụ**:
```
stores/
├── auth.ts      # Authentication state
├── cart.ts      # Shopping cart state
├── products.ts  # Product catalog state
├── ui.ts        # UI state (sidebar, modals)
└── notifications.ts  # Notification system
```

**Khi nào áp dụng**: Applications với multiple features.

---

## 4. Performance

### 4.1 Use v-memo for Large Lists

**Mô tả**: Sử dụng v-memo để skip re-renders cho items không thay đổi.

**Ví dụ**:
```vue
<template>
  <!-- Only re-render when selected changes -->
  <div v-for="item in items" :key="item.id" v-memo="[item.selected]">
    <ComplexComponent :item="item" />
  </div>
</template>
```

**Khi nào áp dụng**: Large lists với items không thay đổi frequently.

### 4.2 Lazy Load Routes

**Mô tả**: Lazy load route components để reduce initial bundle size.

**Ví dụ**:
```typescript
// router/index.ts
import { createRouter, createWebHistory } from 'vue-router';

const routes = [
  {
    path: '/',
    component: () => import('@/views/HomeView.vue'),
  },
  {
    path: '/products',
    component: () => import('@/views/ProductListView.vue'),
  },
  {
    path: '/admin',
    component: () => import('@/views/AdminView.vue'),
    meta: { requiresAuth: true },
  },
];
```

**Khi nào áp dụng**: Tất cả routes ngoại trừ essential pages.

### 4.3 Async Components

**Mô tả**: Lazy load heavy components với defineAsyncComponent.

**Ví dụ**:
```vue
<script setup>
import { defineAsyncComponent } from 'vue';

const HeavyChart = defineAsyncComponent(() => 
  import('./components/HeavyChart.vue')
);

const RichTextEditor = defineAsyncComponent({
  loader: () => import('./components/RichTextEditor.vue'),
  loadingComponent: LoadingSpinner,
  delay: 200,
});
</script>

<template>
  <HeavyChart v-if="showChart" />
  <RichTextEditor v-if="showEditor" />
</template>
```

**Khi nào áp dụng**: Components có size lớn hoặc heavy dependencies.

---

## 5. TypeScript Usage

### 5.1 Strict Type Definitions

**Mô tả**: Define interfaces cho tất cả data structures và component props.

**Ví dụ**:
```typescript
// types/product.ts
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  images: string[];
  category: Category;
  stock: number;
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
}

export interface ProductFilters {
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  search?: string;
  sortBy?: 'price' | 'name' | 'createdAt';
  sortOrder?: 'asc' | 'desc';
}
```

**Khi nào áp dụng**: Mọi data structures trong application.

### 5.2 Type-Safe Composables

**Mô tả**: Ensure composables return properly typed values.

**Ví dụ**:
```typescript
// composables/useCounter.ts
import { ref, computed } from 'vue';

interface UseCounterOptions {
  min?: number;
  max?: number;
}

export function useCounter(initialValue = 0, options: UseCounterOptions = {}) {
  const count = ref(initialValue);
  
  const increment = () => {
    if (options.max === undefined || count.value < options.max) {
      count.value++;
    }
  };
  
  const decrement = () => {
    if (options.min === undefined || count.value > options.min) {
      count.value--;
    }
  };
  
  const reset = () => {
    count.value = initialValue;
  };
  
  return {
    count: readonly(count),
    increment,
    decrement,
    reset,
  };
}

// Usage
const { count, increment } = useCounter(0, { min: 0, max: 10 });
```

**Khi nào áp dụng**: Mọi composables.

---

## 6. Testing

### 6.1 Unit Testing Composables

**Mô tả**: Test composables independently từ components.

**Ví dụ**:
```typescript
// composables/__tests__/useCounter.test.ts
import { describe, it, expect } from 'vitest';
import { useCounter } from '../useCounter';

describe('useCounter', () => {
  it('increments count', () => {
    const { count, increment } = useCounter(0);
    
    increment();
    
    expect(count.value).toBe(1);
  });
  
  it('respects max option', () => {
    const { count, increment } = useCounter(10, { max: 10 });
    
    increment();
    
    expect(count.value).toBe(10); // Should not exceed max
  });
  
  it('respects min option', () => {
    const { count, decrement } = useCounter(0, { min: 0 });
    
    decrement();
    
    expect(count.value).toBe(0); // Should not go below min
  });
});
```

**Khi nào áp dụng**: Mọi composables.

### 6.2 Component Testing

**Mô tả**: Test components với Vue Test Utils.

**Ví dụ**:
```typescript
// components/__tests__/Counter.test.ts
import { describe, it, expect } from 'vitest';
import { mount } from '@vue/test-utils';
import Counter from '../Counter.vue';

describe('Counter', () => {
  it('renders initial count', () => {
    const wrapper = mount(Counter, {
      props: { initialCount: 5 },
    });
    
    expect(wrapper.find('.count').text()).toBe('5');
  });
  
  it('increments when button clicked', async () => {
    const wrapper = mount(Counter);
    
    await wrapper.find('button').trigger('click');
    
    expect(wrapper.find('.count').text()).toBe('1');
  });
  
  it('emits update event', async () => {
    const wrapper = mount(Counter);
    
    await wrapper.find('button').trigger('click');
    
    expect(wrapper.emitted('update')).toBeTruthy();
    expect(wrapper.emitted('update')[0]).toEqual([1]);
  });
});
```

**Khi nào áp dụng**: Mọi components.

---

## 7. Security

### 7.1 XSS Prevention

**Mô tả**: Prevent XSS attacks bằng cách không v-html với untrusted content.

**Ví dụ**:
```vue
<!-- ❌ DANGEROUS: Never use v-html with user input -->
<template>
  <div v-html="userContent"></div>
</template>

<!-- ✅ SAFE: Use text interpolation -->
<template>
  <div>{{ userContent }}</div>
</template>

<!-- If you must use v-html: -->
<script setup>
import DOMPurify from 'dompurify';

const sanitizedContent = computed(() => {
  return DOMPurify.sanitize(userContent.value);
});
</script>

<template>
  <div v-html="sanitizedContent"></div>
</template>
```

**Khi nào áp dụng**: Khi render HTML content.

### 7.2 CSRF Protection

**Mô tả**: Implement CSRF tokens cho API requests.

**Ví dụ**:
```typescript
// services/api.ts
import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
});

// Add CSRF token to requests
api.interceptors.request.use((config) => {
  const token = document.querySelector('meta[name="csrf-token"]');
  if (token) {
    config.headers['X-CSRF-Token'] = token.content;
  }
  return config;
});
```

**Khi nào áp dụng**: Applications với API backend.

---

## 8. Code Organization

### 8.1 Feature-Based Structure

**Mô tả**: Tổ chức code theo features thay vì types.

**Ví dụ**:
```
src/
├── features/
│   ├── auth/
│   │   ├── components/
│   │   ├── composables/
│   │   ├── stores/
│   │   └── types/
│   ├── products/
│   │   └── ...
│   └── orders/
│       └── ...
└── shared/
    ├── components/
    └── utils/
```

**Khi nào áp dụng**: Medium to large applications.

### 8.2 Barrel Exports

**Mô tả**: Use index files for clean imports.

**Ví dụ**:
```typescript
// features/auth/index.ts
export { default as LoginForm } from './components/LoginForm.vue';
export { default as RegisterForm } from './components/RegisterForm.vue';
export { useAuth } from './composables/useAuth';
export { useAuthStore } from './stores/auth';

// Usage - clean imports
import { LoginForm, useAuth } from '@/features/auth';
```

**Khi nào áp dụng**: Feature modules.

---

## 9. Vue Router

### 9.1 Route Meta Types

**Mô tả**: Define TypeScript types cho route meta.

**Ví dụ**:
```typescript
// router/types.ts
declare module 'vue-router' {
  interface RouteMeta {
    requiresAuth?: boolean;
    role?: 'admin' | 'user' | 'guest';
    title?: string;
  }
}

// Usage
const routes = [
  {
    path: '/admin',
    component: AdminLayout,
    meta: {
      requiresAuth: true,
      role: 'admin',
      title: 'Admin Dashboard',
    },
  },
];
```

**Khi nào áp dụng**: Routes với meta information.

### 9.2 Navigation Guards

**Mô tả**: Use navigation guards for auth và permission checks.

**Ví dụ**:
```typescript
// router/guards.ts
import { useAuthStore } from '@/stores/auth';

export async function authGuard(to: RouteLocationNormalized) {
  const authStore = useAuthStore();
  
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    return {
      path: '/login',
      query: { redirect: to.fullPath },
    };
  }
  
  if (to.meta.role && !authStore.hasRole(to.meta.role)) {
    return { path: '/unauthorized' };
  }
}

// router/index.ts
router.beforeEach(authGuard);
```

**Khi nào áp dụng**: Protected routes.

---

## 10. Build & Deployment

### 10.1 Environment Variables

**Mô tả**: Sử dụng environment variables đúng cách.

**Ví dụ**:
```bash
# .env - Default
VITE_API_URL=http://localhost:3000
VITE_APP_NAME="My App"

# .env.production - Production
VITE_API_URL=https://api.example.com
VITE_APP_NAME="My App"
```

```typescript
// Usage
const apiUrl = import.meta.env.VITE_API_URL;
```

**Khi nào áp dụng**: Configuration values.

### 10.2 Asset Handling

**Mô tả**: Handle static assets đúng cách.

**Ví dụ**:
```vue
<template>
  <!-- Images in public/ -->
  <img src="/images/logo.png" alt="Logo" />
  
  <!-- Dynamic images -->
  <img :src="getImageUrl(product.image)" :alt="product.name" />
</template>

<script setup>
import imageUrl from '@/assets/images/logo.png';

// or dynamically
function getImageUrl(name: string) {
  return new URL(`/assets/images/${name}`, import.meta.url).href;
}
</script>
```

**Khi nào áp dụng**: Static assets.

---

## Liên kết liên quan
- [Vue Glossary](./glossary.md)
- [Vue Architecture](./architecture.md)
- [Vue Anti-Patterns](./anti-pattern.md)
- [Vue Checklist](./checklist.md)
- [Vue FAQ](./faq.md)
- [Vue Decision Tree](./decision-tree.md)
