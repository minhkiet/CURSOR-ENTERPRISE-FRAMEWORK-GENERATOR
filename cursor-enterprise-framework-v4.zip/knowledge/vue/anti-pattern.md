# Vue.js Anti-Patterns - Các Mẫu Cần Tránh

## Mục lục
1. [Component Anti-Patterns](#1-component-anti-patterns)
2. [State Management Anti-Patterns](#2-state-management-anti-patterns)
3. [Reactivity Anti-Patterns](#3-reactivity-anti-patterns)
4. [Performance Anti-Patterns](#4-performance-anti-patterns)
5. [Code Organization Anti-Patterns](#5-code-organization-anti-patterns)

---

## 1. Component Anti-Patterns

### 1.1 Mutating Props Directly

**Tên Pattern**: Prop Mutation

**Mô tả**: Thay đổi props trực tiếp trong child component. Props trong Vue là read-only và không nên bị mutate.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
// ❌ BAD: Mutating prop directly
const props = defineProps<{ initialCount: number }>();

function increment() {
  props.initialCount++; // ❌ Mutation!
}
</script>
```

**Hậu quả**:
- Vue warnings trong development
- Unpredictable behavior
- Khó debug khi data flow không rõ ràng
- Có thể break Vue's reactivity system

**Giải pháp thay thế**:
```vue
<script setup>
// ✅ GOOD: Use local state
const props = defineProps<{ initialCount: number }>();

const count = ref(props.initialCount);

function increment() {
  count.value++;
}

// If you need to sync with parent, use v-model
// Parent: <Counter v-model="parentCount" />
// Child: const modelValue = defineModel()
</script>
```

---

### 1.2 Complex Prop drilling

**Tên Pattern**: Prop Drilling

**Mô tả**: Truyền props qua nhiều levels của component tree mà không cần thiết.

**Ví dụ (Anti-Pattern)**:
```vue
<!-- App.vue -->
<template>
  <GrandParentComponent 
    :user-id="userId"
    :user-name="userName"
    :user-email="userEmail"
    :user-role="userRole"
  />
</template>

<!-- GrandParentComponent.vue -->
<template>
  <ParentComponent
    :user-id="userId"
    :user-name="userName"
    :user-email="userEmail"
    :user-role="userRole"
  />
</template>

<!-- ParentComponent.vue -->
<template>
  <ChildComponent
    :user-id="userId"
    :user-name="userName"
    :user-email="userEmail"
    :user-role="userRole"
  />
</template>
```

**Hậu quả**:
- Code duplication
- Khó maintain khi cần thay đổi prop structure
- Components trung gian nhận props không cần thiết
- Props có thể bị misspell hoặc bị bỏ qua

**Giải pháp thay thế**:
```vue
<!-- Option 1: Provide/Inject -->
<!-- GrandParentComponent.vue -->
<script setup>
import { provide } from 'vue';

const user = computed(() => ({
  id: userId.value,
  name: userName.value,
  email: userEmail.value,
  role: userRole.value,
}));

provide('user', user);
</script>

<!-- ChildComponent.vue -->
<script setup>
import { inject } from 'vue';

const user = inject('user');
</script>

<!-- Option 2: Pinia Store -->
<!-- Define userStore -->
<!-- Inject in any component that needs it -->
```

---

### 1.3 Using Index as Key in v-for

**Tên Pattern**: Index Key

**Mô tả**: Sử dụng index của array như :key trong v-for, đặc biệt khi array có thể reorder hoặc remove items.

**Ví dụ (Anti-Pattern)**:
```vue
<template>
  <!-- ❌ BAD: Using index as key -->
  <div v-for="(item, index) in items" :key="index">
    <ItemComponent :item="item" @remove="items.splice(index, 1)" />
  </div>
</template>
```

**Hậu quả**:
- Vue có thể reuse wrong DOM elements khi list thay đổi
- Focus state có thể bị lost
- Animation transitions có thể broken
- Form inputs có thể show sai data

**Giải pháp thay thế**:
```vue
<template>
  <!-- ✅ GOOD: Use unique identifier as key -->
  <div v-for="item in items" :key="item.id">
    <ItemComponent :item="item" @remove="removeItem(item.id)" />
  </div>
</template>

<script setup>
function removeItem(id: string) {
  items.value = items.value.filter(item => item.id !== id);
}
</script>
```

---

## 2. State Management Anti-Patterns

### 2.1 Overusing Vuex/Pinia

**Tên Pattern**: State Over-Engineering

**Mô tả**: Sử dụng Pinia/Vuex cho tất cả state, kể cả local component state không cần share.

**Ví dụ (Anti-Pattern)**:
```typescript
// ❌ BAD: Store for local state
export const useFormState = defineStore('formState', () => {
  const isSubmitting = ref(false);
  const error = ref<string | null>(null);
  const formData = ref({ name: '', email: '' });
  
  return { isSubmitting, error, formData };
});
```

**Hậu quả**:
- Overhead cho simple state management
- Components có thể modify global state accidentally
- Khó track state changes
- Bundle size tăng không cần thiết

**Giải pháp thay thế**:
```vue
<script setup>
// ✅ GOOD: Use local state for form
const isSubmitting = ref(false);
const error = ref<string | null>(null);
const formData = ref({ name: '', email: '' });
</script>
```

---

### 2.2 Not Centralizing Async Operations

**Tên Pattern**: Scattered Async Logic

**Mô tả**: Thực hiện API calls ở nhiều nơi khác nhau thay vì centralize trong services/stores.

**Ví dụ (Anti-Pattern)**:
```vue
<!-- ❌ BAD: API calls scattered everywhere -->
<script setup>
import axios from 'axios';

async function saveUser() {
  const response = await axios.post('/api/users', this.formData);
  // Handle response
}

async function loadUsers() {
  const response = await axios.get('/api/users');
  // Handle response
}

async function deleteUser(id) {
  const response = await axios.delete(`/api/users/${id}`);
  // Handle response
}
</script>
```

**Hậu quả**:
- Code duplication
- Khó maintain duplicate error handling
- Inconsistent API interactions
- Khó test

**Giải pháp thay thế**:
```typescript
// ✅ GOOD: Centralize API logic
// services/user.service.ts
export const userService = {
  async save(user: User): Promise<User> {
    return api.post('/users', user);
  },
  
  async list(): Promise<User[]> {
    return api.get('/users');
  },
  
  async delete(id: string): Promise<void> {
    return api.delete(`/users/${id}`);
  },
};

// Component
import { userService } from '@/services/user.service';

async function saveUser() {
  const user = await userService.save(formData);
  // Handle
}
```

---

### 2.3 Not Handling Loading/Error States

**Tên Pattern**: Missing Error Handling

**Mô tả**: Không handle loading và error states cho async operations.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
const user = ref(null);

async function loadUser() {
  const response = await axios.get('/api/user');
  user.value = response.data;
}
</script>

<template>
  <!-- ❌ BAD: No loading/error handling -->
  <div>{{ user.name }}</div>
</template>
```

**Hậu quả**:
- Users thấy blank screen hoặc errors
- Poor user experience
- Debugging becomes difficult
- Potential for undefined errors

**Giải pháp thay thế**:
```vue
<script setup>
const user = ref<User | null>(null);
const loading = ref(false);
const error = ref<string | null>(null);

async function loadUser() {
  loading.value = true;
  error.value = null;
  
  try {
    const response = await axios.get('/api/user');
    user.value = response.data;
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load user';
  } finally {
    loading.value = false;
  }
}
</script>

<template>
  <div v-if="loading">
    <Spinner />
  </div>
  <div v-else-if="error" class="error">
    {{ error }}
    <button @click="loadUser">Thử lại</button>
  </div>
  <div v-else-if="user">
    {{ user.name }}
  </div>
</template>
```

---

## 3. Reactivity Anti-Patterns

### 3.1 Replacing Entire Reactive Object

**Tên Pattern**: Object Replacement

**Mô tả**: Thay thế entire reactive object thay vì modify properties.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
const user = reactive({ name: 'John', age: 30 });

function updateUser() {
  // ❌ BAD: Replacing object breaks reactivity
  user.value = { name: 'Jane', age: 25 };
}

function updateUser() {
  // ❌ Also bad
  Object.assign(user, { name: 'Jane', age: 25 });
}
</script>
```

**Hậu quả**:
- Vue có thể không detect changes
- References có thể break
- Watchers có thể không trigger

**Giải pháp thay thế**:
```vue
<script setup>
const user = reactive({ name: 'John', age: 30 });

// ✅ GOOD: Modify properties
function updateUser() {
  user.name = 'Jane';
  user.age = 25;
}

// Or use ref instead of reactive for objects
const user = ref({ name: 'John', age: 30 });

function updateUser() {
  user.value = { name: 'Jane', age: 25 }; // This works with ref
}
</script>
```

---

### 3.2 Accessing this in Arrow Functions

**Tên Pattern**: Arrow Function in Options API

**Mô tả**: Sử dụng arrow functions với `this` trong Options API methods.

**Ví dụ (Anti-Pattern)**:
```javascript
export default {
  data() {
    return { count: 0 };
  },
  
  // ❌ BAD: Arrow function loses 'this' context
  methods: {
    increment: () => {
      this.count++; // ❌ 'this' is undefined
    },
  },
};
```

**Hậu quả**:
- `this` không refer đến Vue instance
- Methods không access được data hoặc other methods
- Runtime errors

**Giải pháp thay thế**:
```javascript
export default {
  data() {
    return { count: 0 };
  },
  
  // ✅ GOOD: Regular function
  methods: {
    increment() {
      this.count++;
    },
  },
};

// Or use Composition API
const count = ref(0);
const increment = () => {
  count.value++; // count is in scope
};
```

---

## 4. Performance Anti-Patterns

### 4.1 Not Using Computed for Derived State

**Tên Pattern**: Derived State in Methods

**Mô tả**: Tính toán derived values trong methods thay vì computed properties.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
const items = ref([1, 2, 3, 4, 5]);

// ❌ BAD: Computing in template
function getFilteredItems() {
  return items.value.filter(i => i > 2);
}
</script>

<template>
  <!-- getFilteredItems() được gọi mỗi render -->
  <div v-for="item in getFilteredItems()">{{ item }}</div>
</template>
```

**Hậu quả**:
- Computed mỗi lần render
- No caching
- Performance degradation với complex computations
- Khó debug

**Giải pháp thay thế**:
```vue
<script setup>
const items = ref([1, 2, 3, 4, 5]);

// ✅ GOOD: Use computed
const filteredItems = computed(() => {
  return items.value.filter(i => i > 2);
});
</script>

<template>
  <!-- filteredItems được cache và chỉ compute khi items thay đổi -->
  <div v-for="item in filteredItems">{{ item }}</div>
</template>
```

---

### 4.2 Unnecessary Deep Reactive Objects

**Tên Pattern**: Over-Reactive

**Mô tả**: Sử dụng reactive() cho deeply nested objects khi không cần thiết.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
import { reactive } from 'vue';

// ❌ BAD: Deep reactivity for large objects
const appState = reactive({
  users: [/* large array */],
  products: [/* large array */],
  settings: { /* ... */ },
});
</script>
```

**Hậu quả**:
- Performance overhead cho deep reactive conversion
- Memory usage cao hơn
- Slower updates

**Giải pháp thay thế**:
```vue
<script setup>
import { ref, shallowReactive, readonly } from 'vue';

// ✅ GOOD: Use shallowReactive for large objects
const appState = shallowReactive({
  users: [],
  products: [],
});

// ✅ GOOD: Use ref for objects that don't need deep tracking
const settings = ref({
  theme: 'dark',
  language: 'vi',
});
</script>
```

---

### 4.3 Not Lazy Loading Heavy Components

**Tên Pattern**: Eager Loading

**Mô tả**: Import tất cả components cùng lúc, làm tăng initial bundle size.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
import HeavyChart from '@/components/HeavyChart.vue';
import RichTextEditor from '@/components/RichTextEditor.vue';
import ImageGallery from '@/components/ImageGallery.vue';
import DataTable from '@/components/DataTable.vue';
// All loaded immediately
</script>
```

**Hậu quả**:
- Initial load time tăng
- Bundle size lớn
- Poor mobile performance
- User phải download tất cả kể cả khi không dùng

**Giải pháp thay thế**:
```vue
<script setup>
import { defineAsyncComponent } from 'vue';

const HeavyChart = defineAsyncComponent(() => 
  import('@/components/HeavyChart.vue')
);

const RichTextEditor = defineAsyncComponent(() => 
  import('@/components/RichTextEditor.vue')
);
</script>
```

---

## 5. Code Organization Anti-Patterns

### 5.1 Magic Strings Everywhere

**Tên Pattern**: Hardcoded Constants

**Mô tả**: Sử dụng magic strings thay vì constants/constants file.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
// ❌ BAD: Magic strings scattered
if (user.role === 'admin') { /* ... */ }

api.post('/api/users/update');

if (status === 'pending') { /* ... */ }

const STORAGE_KEY = 'user_data';
</script>
```

**Hậu quả**:
- Typos có thể gây ra bugs
- Khó search và replace
- Inconsistent values across codebase
- Khó maintain

**Giải pháp thay thế**:
```typescript
// constants/index.ts
export const ROLES = {
  ADMIN: 'admin',
  USER: 'user',
  GUEST: 'guest',
} as const;

export const API = {
  USERS: '/api/users',
  PRODUCTS: '/api/products',
} as const;

export const STATUS = {
  PENDING: 'pending',
  ACTIVE: 'active',
  COMPLETED: 'completed',
} as const;

export const STORAGE_KEYS = {
  USER_DATA: 'user_data',
  THEME: 'theme',
} as const;

// Component
import { ROLES, API, STATUS } from '@/constants';

if (user.role === ROLES.ADMIN) { /* ... */ }
api.post(API.USERS);
```

---

### 5.2 Mixing Options API and Composition API

**Tên Pattern**: Mixed API Styles

**Mô tả**: Sử dụng cả Options API và Composition API trong cùng component không có lý do rõ ràng.

**Ví dụ (Anti-Pattern)**:
```vue
<script>
export default {
  // ❌ Mixing styles
  data() {
    return { count: 0 };
  },
  
  computed: {
    doubleCount() {
      return this.count * 2;
    },
  },
  
  methods: {
    increment() {
      this.count++;
    },
  },
};
</script>

<script setup>
import { ref } from 'vue';

// ❌ And also using setup
const name = ref('');
</script>
```

**Hậu quả**:
- Confusion về data flow
- Khó maintain
- Duplicate logic có thể xảy ra
- Performance overhead

**Giải pháp thay thế**:
```vue
<!-- Option: Use only Composition API -->
<script setup>
import { ref, computed } from 'vue';

const count = ref(0);
const doubleCount = computed(() => count.value * 2);

function increment() {
  count.value++;
}
</script>

<!-- Or: Use only Options API -->
<script>
export default {
  data() {
    return { count: 0 };
  },
  computed: {
    doubleCount() {
      return this.count * 2;
    },
  },
  methods: {
    increment() {
      this.count++;
    },
  },
};
</script>
```

---

### 5.3 Not Using index.ts for Exports

**Tên Pattern**: Deep Imports

**Mô tả**: Import từ deep file paths thay vì barrel exports.

**Ví dụ (Anti-Pattern)**:
```vue
<script setup>
import { useAuthStore } from '@/features/auth/stores/auth.store.ts';
import { LoginForm } from '@/features/auth/components/LoginForm.vue';
import { useFormatters } from '@/shared/utils/formatters.ts';
</script>
```

**Hậu quả**:
- Long import paths
- Khó refactor (rename folder)
- Inconsistent imports
- Maintenance burden

**Giải pháp thay thế**:
```typescript
// features/auth/index.ts
export { useAuthStore } from './stores/auth.store';
export { LoginForm, RegisterForm } from './components';

// shared/utils/index.ts
export * from './formatters';
export * from './validators';

// Component
import { useAuthStore, LoginForm } from '@/features/auth';
import { formatCurrency } from '@/shared/utils';
```

---

## Liên kết liên quan
- [Vue Glossary](./glossary.md)
- [Vue Architecture](./architecture.md)
- [Vue Best Practices](./best-practice.md)
- [Vue Checklist](./checklist.md)
- [Vue FAQ](./faq.md)
- [Vue Decision Tree](./decision-tree.md)
