# Tử Vi Decision Tree - Cây Quyết Định

## Giới thiệu

Cây quyết định này hướng dẫn developers và system designers trong việc đưa ra các quyết định kiến trúc và triển khai cho hệ thống Tử Vi Đẩu Số.

## Quyết định về Core Calculation

### Câu hỏi: Nên implement calculation engine như thế nào?

- **Monolithic Engine**
  - Phù hợp khi: Team nhỏ, dự án ban đầu
  - Pros: Đơn giản, easy to start
  - Cons: Khó scale, khó maintain khi phức tạp
  - Khi nào: Prototype, MVPs

- **Modular Engine với Plugins**
  - Phù hợp khi: Dự án lớn, nhiều người
  - Approach: Từng vòng tròn như module riêng
  - Pros: Flexible, maintainable, extensible
  - Cons: Complexity trong integration
  - Khi nào: Production systems

### Câu hỏi: Nên sử dụng ngôn ngữ nào cho calculation?

- **JavaScript/TypeScript**
  - Pros: Unified codebase, easy deployment
  - Cons: Performance có thể là vấn đề với calculations nặng
  - Khi nào: Web-focused applications

- **Python**
  - Pros: Great for AI/ML integration, rapid development
  - Cons: Performance, deployment complexity
  - Khi nào: AI-heavy applications

- **Go/Rust**
  - Pros: High performance, concurrency
  - Cons: Learning curve, less ecosystem
  - Khi nào: High-performance requirements

## Quyết định về Data Model

### Câu hỏi: Nên lưu trữ readings như thế nào?

- **Relational Database (PostgreSQL)**
  - Phù hợp khi: ACID compliance, complex queries
  - Approach: Normalized schema với separate tables cho palaces, stars, cycles
  - Khi nào: Enterprise applications

- **Document Database (MongoDB)**
  - Phù hợp khi: Flexible schema, nested data
  - Approach: Single document per reading với nested structure
  - Khi nào: Agile development, frequent schema changes

- **Hybrid**
  - Approach: PostgreSQL cho core data, MongoDB cho readings
  - Khi nào: Complex requirements

## Quyết định về Chart Visualization

### Câu hỏi: Nên implement chart visualization như thế nào?

- **SVG-based Rendering**
  - Pros: Resolution-independent, accessible
  - Cons: Limited interactivity
  - Khi nào: Simple charts, accessibility priority

- **Canvas-based Rendering**
  - Pros: High performance, rich interactivity
  - Cons: Less accessible, complex implementation
  - Khi nào: Complex interactions, animations

- **WebGL**
  - Pros: High performance, 3D capabilities
  - Cons: Complexity, browser support
  - Khi nào: 3D charts, gaming-like interactions

### Câu hỏi: Nên sử dụng thư viện visualization nào?

- **D3.js**
  - Pros: Powerful, flexible
  - Cons: Steep learning curve
  - Khi nào: Custom visualizations

- **ECharts**
  - Pros: Rich features, good documentation
  - Cons: Bundle size
  - Khi nào: General purpose charts

- **Custom Implementation**
  - Pros: Full control
  - Cons: Time-consuming
  - Khi nào: Unique requirements

## Quyết định về AI Integration

### Câu hỏi: Nên sử dụng AI như thế nào?

- **Rule-based với AI Enhancement**
  - Approach: Core logic là rule-based, AI cho interpretations
  - Khi nào: Accuracy priority

- **ML-powered Analysis**
  - Approach: Train models trên historical readings
  - Khi nào: Pattern discovery priority

- **LLM-powered Generation**
  - Approach: Use LLMs cho natural language generation
  - Khi nào: Conversational interfaces

## Quyết định về API Design

### Câu hỏi: Nên expose calculation engine qua API như thế nào?

- **RESTful API**
  - Endpoints: /readings, /palaces, /stars, /fortunes
  - Khi nào: Standard web applications

- **GraphQL**
  - Pros: Flexible queries
  - Cons: Complexity
  - Khi nào: Multiple client types

- **gRPC**
  - Pros: High performance
  - Cons: Browser limitations
  - Khi nào: Internal services

## Quyết định về Caching

### Câu hỏi: Nên cache những gì?

- **Cache Static Calculations**
  - Items: Palace positions, basic star allocations
  - TTL: Permanent
  - Khi nào: Always

- **Cache User Readings**
  - Items: Computed readings
  - TTL: Medium
  - Khi nào: Most applications

- **Cache Fortunes**
  - Items: Vận calculations
  - TTL: Short (daily)
  - Khi nào: Performance optimization

## Quyết định về Performance Optimization

### Câu hỏi: Làm thế nào để optimize performance?

- **Pre-computation**
  - Approach: Pre-compute readings cho common birth times
  - Khi nào: Known user base

- **Caching**
  - Approach: Cache results của expensive calculations
  - Khi nào: Most applications

- **Async Processing**
  - Approach: Background job processing cho heavy calculations
  - Khi nào: Non-real-time scenarios

- **Horizontal Scaling**
  - Approach: Scale out calculation engines
  - Khi nào: High traffic

## Summary

Sử dụng cây quyết định này như starting point và document các decisions trong ADRs để maintain institutional knowledge.
