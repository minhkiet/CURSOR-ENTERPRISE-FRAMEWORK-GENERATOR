# Numerology Architecture - Kiến Trúc Hệ Thống Thần Số Học

## Tổng quan kiến trúc

Hệ thống Thần Số Học được thiết kế trên nền tảng kiến trúc đơn giản nhưng hiệu quả, phù hợp với bản chất toán học của các phép tính. Kiến trúc tập trung vào độ chính xác của các phép tính, khả năng mở rộng cho nhiều phương pháp tính toán, và giao diện người dùng trực quan. Hệ thống bao gồm các thành phần chính: Calculation Engine, API Gateway, Database Layer, Cache Layer, AI Services, và Frontend Applications.

## Kiến trúc chi tiết các thành phần

### 1. Core Calculation Engine - Tầng Xử Lý Tính Toán Cốt Lõi

Core Calculation Engine là thành phần quan trọng nhất của hệ thống Thần Số Học, chịu trách nhiệm thực hiện tất cả các phép tính số học. Module này được viết bằng TypeScript với pure functions để đảm bảo tính predictable và testable. Các thành phần chính bao gồm: NumerologyCalculator (tính toán các chỉ số cơ bản), NameAnalyzer (phân tích tên), DateAnalyzer (phân tích ngày sinh), CycleProcessor (xử lý các chu kỳ), và ChartGenerator (tạo biểu đồ).

NumerologyCalculator là module trung tâm xử lý các phép tính cơ bản: reduceNumber (rút gọn số), calculateLifePath (tính Số Chủ Đạo), calculateSoulUrge (tính Số Linh Hồn), calculatePersonality (tính Số Nhân Cách), calculateExpression (tính Số Biểu Đạt), calculateBirthDay (tính Số Ngày Sinh). Mỗi function được implement với các test cases đầy đủ để đảm bảo độ chính xác.

NameAnalyzer xử lý các phép tính liên quan đến tên: extractVowels (trích xuất nguyên âm), extractConsonants (trích xuất phụ âm), convertToNumbers (chuyển đổi sang số theo bảng), calculateNameNumbers (tính các chỉ số từ tên). Module này cần xử lý cả tiếng Anh (bảng alphabet) và tiếng Việt (chuyển đổi sang alphabet trước khi tính).

DateAnalyzer xử lý các phép tính liên quan đến ngày sinh: parseDate (phân tích ngày sinh), validateDate (kiểm tra tính hợp lệ), calculateLifePathFromDate (tính Số Chủ Đạo từ ngày sinh), identifyRepeatingNumbers (xác định các số lặp), detectTriangularNumbers (phát hiện số tam giác).

CycleProcessor xử lý các chu kỳ trong Thần Số Học: calculatePersonalYear (tính Hạn Số cá nhân), calculatePersonalMonth (tính tháng cá nhân), calculatePersonalDay (tính ngày cá nhân), calculatePinnacles (tính Đỉnh Cao), calculateChallenges (tính Thách Thức). Module này cần handle leap years và các edge cases liên quan đến ngày tháng.

### 2. API Gateway Layer - Tầng Cổng API

API Gateway được implement bằng Node.js/Express hoặc Next.js API routes, đóng vai trò điểm đầu vào duy nhất cho tất cả các requests. Layer này xử lý authentication, authorization, rate limiting, request validation, và response formatting. Tất cả API endpoints được định nghĩa rõ ràng trong OpenAPI Specification.

Authentication sử dụng JWT tokens với refresh token mechanism. Users được xác thực qua email/password hoặc OAuth providers. Mỗi user có một profile chứa thông tin Numerology đã được tính toán sẵn. Subscription tiers được enforce để giới hạn access đến certain features.

Request validation sử dụng Joi hoặc Zod schemas để validate tất cả inputs trước khi xử lý. Date validation đặc biệt quan trọng để ensure ngày sinh hợp lệ. Name validation đảm bảo tên không chứa các ký tự không hỗ trợ.

### 3. Data Access Layer - Tầng Truy Cập Dữ Liệu

Data Access Layer sử dụng PostgreSQL làm database chính với Prisma ORM. Repository Pattern được sử dụng để tách biệt logic truy cập dữ liệu khỏi business logic. Các repositories chính bao gồm: UserRepository, ReadingRepository, CalculationHistoryRepository, và SubscriptionRepository.

UserRepository quản lý thông tin người dùng: profile, authentication data, subscription status, preferences (preferred calculation method, language). Indexes được tạo trên các trường thường xuyên truy vấn như email, phone, subscription tier.

ReadingRepository lưu trữ các lá số đã tính toán. Document structure bao gồm: user_id, birth_date, full_name, calculation_method, numbers (object chứa tất cả các chỉ số đã tính), created_at, calculation_version. Readings được versioned để track changes và compare.

### 4. Caching Layer - Tầng Cache

Redis được sử dụng cho caching với chiến lược cache-aside pattern. Static calculations (như convert alphabet sang numbers) được cached vĩnh viễn. User-specific readings được cached với medium TTL và invalidated khi user update profile.

Personal Year/Month/Day calculations có TTL ngắn vì chúng phụ thuộc vào thời gian hiện tại. Cache warming được implement để pre-calculate upcoming personal years cho active users.

### 5. AI Services Layer - Tầng Dịch Vụ AI

AI Services cung cấp các tính năng thông minh: InterpretationEngine (phân tích các chỉ số bằng ngôn ngữ tự nhiên), RecommendationEngine (đề xuất cá nhân hóa), PersonalizedContentService (nội dung cá nhân hóa), PredictionEngine (dự đoán xu hướng).

InterpretationEngine sử dụng NLP models để tạo ra các bản phân tích tự động dựa trên các chỉ số đã tính. Engine nhận structured Numerology data và output các paragraphs về tính cách, điểm mạnh, điểm yếu, và đề xuất. Quality của interpretations được improved thông qua feedback loop từ users.

### 6. Frontend Applications - Các Ứng Dụng Frontend

Web Application được xây dựng bằng Next.js với Tailwind CSS. Application bao gồm các trang chính: landing page, user dashboard, Numerology calculator, reading viewer, personalized recommendations, settings. UI được design với focus vào clarity và ease of use.

Interactive Number Wheel là một trong những tính năng quan trọng nhất của frontend. Users có thể xem tất cả các chỉ số được visualize dưới dạng bánh xe số với các connections giữa các số liên quan. Interactive features cho phép users click vào từng số để xem chi tiết.

Mobile Application được phát triển bằng React Native cho cả iOS và Android. App bao gồm các tính năng tương tự web application nhưng được optimized cho touch interfaces.

## Database Schema Design

### Core Tables

Users table chứa thông tin authentication và profile. Các trường quan trọng: id (UUID), email, password_hash, phone, birth_date, birth_time, birth_timezone, gender, full_name, calculation_method (Pythagorean/Chaldean), created_at, updated_at, subscription_tier.

NumerologyReadings table lưu trữ các lá số đã tính toán. Document structure: {user_id, birth_date, full_name, life_path_number, soul_urge_number, personality_number, expression_number, birth_day_number, personal_year, personal_month, personal_day, repeating_numbers, triangular_numbers, created_at, calculation_version}.

PersonalCycles table lưu trữ các chu kỳ cá nhân. Document structure: {user_id, cycle_type, start_date, end_date, numbers, interpretation, created_at}.

## Security Architecture

Authentication sử dụng JWT tokens với appropriate expiration và rotation. Passwords được hashed bằng bcrypt. OAuth 2.0 flows cho social logins. MFA available cho enhanced security.

Data encryption được applied ở cả data-at-rest và data-in-transit. TLS 1.3 được enforced. Sensitive fields được encrypted at application level.

## Deployment Architecture

Container orchestration sử dụng Docker với docker-compose cho development và Kubernetes cho production. CI/CD pipeline sử dụng GitHub Actions.

Monitoring và observability với Prometheus, Grafana, và ELK stack.

## Scalability và Performance

Database read replicas cho read-heavy workloads. Redis caching cho expensive calculations. CDN cho static assets.

Asynchronous processing với message queues cho heavy computations và AI interpretations.

## Integration Architecture

Payment integrations với Stripe cho subscriptions. Notification integrations với email, SMS, và push notification. Calendar integration cho syncing important dates.

## Kết luận

Kiến trúc Numerology được thiết kế để handle tính toán chính xác và provide great user experience. Focus vào performance, accuracy, và personalization giúp build engaging product.
